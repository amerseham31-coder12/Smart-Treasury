# Client Portal Visual Verification

The admin credential screen renders the Arabic form for client name, username, and password, together with a clear read-only access explanation. The capital portal renders the separate tabs for رأس مالي, Vodafone Cash, InstaPay, and تقرير العمليات. The capital view shows an aggregate balance card and provider-specific cards with zero values when no operational accounts exist, which avoids fabricated financial data.

The operations report renders the automatic refresh message, a five-second refresh cadence, a search field, and an empty state. One provider screenshot captured its loading skeleton during the first protected data request; the settled capital and operations layouts were visible and the project TypeScript/build checks were clean.

The final project health check reports a running dev server, dependencies OK, no language-service errors, and no TypeScript errors. The root preview may display the auth-loading skeleton during a fresh protected navigation; the settled portal and credential pages rendered correctly in the dedicated route captures.
