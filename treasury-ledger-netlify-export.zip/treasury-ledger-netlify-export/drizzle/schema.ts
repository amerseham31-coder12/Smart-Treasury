import {
  boolean,
  date,
  decimal,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const clientCredentials = mysqlTable(
  "client_credentials",
  {
    id: int("id").autoincrement().primaryKey(),
    username: varchar("username", { length: 80 }).notNull(),
    passwordHash: varchar("passwordHash", { length: 128 }).notNull(),
    passwordSalt: varchar("passwordSalt", { length: 64 }).notNull(),
    userId: int("userId").notNull(),
    workspaceId: int("workspaceId").notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    clientUsernameUnique: uniqueIndex("client_credentials_username_unique").on(table.username),
    workspaceCredentialIdx: index("client_credentials_workspace_idx").on(table.workspaceId),
  }),
);

export const workspaces = mysqlTable("workspaces", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  baseCurrency: varchar("baseCurrency", { length: 3 }).default("EGP").notNull(),
  timezone: varchar("timezone", { length: 64 }).default("Africa/Cairo").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const workspaceMembers = mysqlTable(
  "workspace_members",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    userId: int("userId").notNull(),
    role: mysqlEnum("role", ["admin", "employee", "accountant", "client"]).default("employee").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    workspaceUserUnique: uniqueIndex("workspace_user_unique").on(table.workspaceId, table.userId),
    workspaceIdx: index("workspace_members_workspace_idx").on(table.workspaceId),
  }),
);

export const ledgerAccounts = mysqlTable(
  "ledger_accounts",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    code: varchar("code", { length: 40 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    accountType: mysqlEnum("accountType", ["asset", "liability", "equity", "income", "expense", "receivable", "payable", "external"]).notNull(),
    providerType: mysqlEnum("providerType", ["treasury", "vodafone_cash", "instapay", "cash", "other", "customer", "system"]).default("other").notNull(),
    accountNumber: varchar("accountNumber", { length: 80 }),
    openingBalance: decimal("openingBalance", { precision: 18, scale: 2 }).default("0.00").notNull(),
    lowBalanceThreshold: decimal("lowBalanceThreshold", { precision: 18, scale: 2 }).default("0.00").notNull(),
    allowOverdraft: boolean("allowOverdraft").default(false).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    workspaceCodeUnique: uniqueIndex("ledger_accounts_workspace_code_unique").on(table.workspaceId, table.code),
    workspaceProviderIdx: index("ledger_accounts_workspace_provider_idx").on(table.workspaceId, table.providerType),
  }),
);

export const customers = mysqlTable(
  "customers",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    ledgerAccountId: int("ledgerAccountId").notNull(),
    customerCode: varchar("customerCode", { length: 40 }).notNull(),
    name: varchar("name", { length: 160 }).notNull(),
    phone: varchar("phone", { length: 40 }),
    address: text("address"),
    creditLimit: decimal("creditLimit", { precision: 18, scale: 2 }).default("0.00").notNull(),
    status: mysqlEnum("status", ["active", "inactive", "blocked"]).default("active").notNull(),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    workspaceCustomerCodeUnique: uniqueIndex("customers_workspace_code_unique").on(table.workspaceId, table.customerCode),
    workspaceNameIdx: index("customers_workspace_name_idx").on(table.workspaceId, table.name),
    workspacePhoneIdx: index("customers_workspace_phone_idx").on(table.workspaceId, table.phone),
  }),
);

export const transactions = mysqlTable(
  "transactions",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    transactionId: varchar("transactionId", { length: 48 }).notNull().unique(),
    transactionType: mysqlEnum("transactionType", ["deposit", "withdrawal", "customer_transfer", "customer_receipt", "internal_transfer", "expense", "adjustment", "reversal"]).notNull(),
    sourceAccountId: int("sourceAccountId"),
    destinationAccountId: int("destinationAccountId"),
    customerId: int("customerId"),
    amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
    feeAmount: decimal("feeAmount", { precision: 18, scale: 2 }).default("0.00").notNull(),
    commissionType: mysqlEnum("commissionType", ["incoming", "outgoing"]),
    netAmount: decimal("netAmount", { precision: 18, scale: 2 }).notNull(),
    clientMutationId: varchar("clientMutationId", { length: 80 }),
    externalReference: varchar("externalReference", { length: 120 }),
    notes: text("notes"),
    status: mysqlEnum("status", ["posted", "reversed", "pending"]).default("posted").notNull(),
    originalTransactionId: int("originalTransactionId"),
    createdBy: int("createdBy").notNull(),
    postedAt: timestamp("postedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    workspaceDateIdx: index("transactions_workspace_date_idx").on(table.workspaceId, table.postedAt),
    workspaceTypeIdx: index("transactions_workspace_type_idx").on(table.workspaceId, table.transactionType),
    externalReferenceIdx: index("transactions_external_reference_idx").on(table.workspaceId, table.externalReference),
    clientMutationIdx: uniqueIndex("transactions_workspace_client_mutation_unique").on(table.workspaceId, table.clientMutationId),
  }),
);

export const ledgerEntries = mysqlTable(
  "ledger_entries",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    transactionId: int("transactionId").notNull(),
    accountId: int("accountId").notNull(),
    entryType: mysqlEnum("entryType", ["debit", "credit"]).notNull(),
    amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    transactionIdx: index("ledger_entries_transaction_idx").on(table.transactionId),
    accountIdx: index("ledger_entries_account_idx").on(table.workspaceId, table.accountId),
  }),
);

export const reconciliations = mysqlTable(
  "reconciliations",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    accountId: int("accountId").notNull(),
    reconciliationDate: date("reconciliationDate").notNull(),
    expectedBalance: decimal("expectedBalance", { precision: 18, scale: 2 }).notNull(),
    actualBalance: decimal("actualBalance", { precision: 18, scale: 2 }).notNull(),
    difference: decimal("difference", { precision: 18, scale: 2 }).notNull(),
    reason: text("reason"),
    notes: text("notes"),
    status: mysqlEnum("status", ["matched", "unmatched", "reviewed"]).default("unmatched").notNull(),
    createdBy: int("createdBy").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    workspaceAccountDateUnique: uniqueIndex("reconciliations_workspace_account_date_unique").on(table.workspaceId, table.accountId, table.reconciliationDate),
  }),
);

export const auditLogs = mysqlTable(
  "audit_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    actorUserId: int("actorUserId").notNull(),
    action: varchar("action", { length: 80 }).notNull(),
    entityType: varchar("entityType", { length: 80 }).notNull(),
    entityId: varchar("entityId", { length: 80 }),
    metadata: json("metadata"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    workspaceAuditIdx: index("audit_logs_workspace_created_idx").on(table.workspaceId, table.createdAt),
  }),
);

export const alerts = mysqlTable(
  "alerts",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    alertType: mysqlEnum("alertType", ["low_balance", "credit_limit", "reconciliation_difference", "review"]).notNull(),
    severity: mysqlEnum("severity", ["info", "warning", "critical"]).default("warning").notNull(),
    accountId: int("accountId"),
    customerId: int("customerId"),
    title: varchar("title", { length: 180 }).notNull(),
    message: text("message").notNull(),
    isResolved: boolean("isResolved").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    resolvedAt: timestamp("resolvedAt"),
  },
  table => ({
    workspaceAlertIdx: index("alerts_workspace_resolved_idx").on(table.workspaceId, table.isResolved),
  }),
);

export const commissions = mysqlTable(
  "commissions",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    transactionId: int("transactionId").notNull(),
    commissionType: mysqlEnum("commissionType", ["incoming", "outgoing"]).notNull(),
    amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
    accountId: int("accountId").notNull(),
    createdBy: int("createdBy").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    transactionUnique: uniqueIndex("commissions_transaction_type_unique").on(table.transactionId, table.commissionType),
    workspaceDateIdx: index("commissions_workspace_date_idx").on(table.workspaceId, table.createdAt),
  }),
);

export const personalExpenses = mysqlTable(
  "personal_expenses",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    transactionId: int("transactionId").notNull().unique(),
    expenseType: varchar("expenseType", { length: 100 }).notNull(),
    description: text("description").notNull(),
    amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
    accountId: int("accountId").notNull(),
    notes: text("notes"),
    createdBy: int("createdBy").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ workspaceDateIdx: index("personal_expenses_workspace_date_idx").on(table.workspaceId, table.createdAt) }),
);

export const customerPayables = mysqlTable(
  "customer_payables",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    customerId: int("customerId").notNull(),
    sourceTransactionId: int("sourceTransactionId").notNull().unique(),
    dueAmount: decimal("dueAmount", { precision: 18, scale: 2 }).notNull(),
    paidAmount: decimal("paidAmount", { precision: 18, scale: 2 }).default("0.00").notNull(),
    dueDate: date("dueDate").notNull(),
    paidAt: timestamp("paidAt"),
    status: mysqlEnum("status", ["pending", "partially_paid", "paid"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ workspaceStatusIdx: index("customer_payables_workspace_status_idx").on(table.workspaceId, table.status) }),
);

export const dailyClosings = mysqlTable(
  "daily_closings",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    closingDate: date("closingDate").notNull(),
    openingBalance: decimal("openingBalance", { precision: 18, scale: 2 }).notNull(),
    totalInflows: decimal("totalInflows", { precision: 18, scale: 2 }).notNull(),
    totalOutflows: decimal("totalOutflows", { precision: 18, scale: 2 }).notNull(),
    incomingCommissions: decimal("incomingCommissions", { precision: 18, scale: 2 }).notNull(),
    outgoingCommissions: decimal("outgoingCommissions", { precision: 18, scale: 2 }).notNull(),
    personalExpenses: decimal("personalExpenses", { precision: 18, scale: 2 }).notNull(),
    vodafoneMovements: decimal("vodafoneMovements", { precision: 18, scale: 2 }).notNull(),
    customerPayables: decimal("customerPayables", { precision: 18, scale: 2 }).notNull(),
    closingBalance: decimal("closingBalance", { precision: 18, scale: 2 }).notNull(),
    transactionCount: int("transactionCount").notNull(),
    warnings: json("warnings"),
    isReopened: boolean("isReopened").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ workspaceDateUnique: uniqueIndex("daily_closings_workspace_date_unique").on(table.workspaceId, table.closingDate) }),
);

export const transferScreenshots = mysqlTable(
  "transfer_screenshots",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    transactionId: int("transactionId").notNull().unique(),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    storageUrl: varchar("storageUrl", { length: 512 }).notNull(),
    enteredAmount: decimal("enteredAmount", { precision: 18, scale: 2 }).notNull(),
    extractedAmount: decimal("extractedAmount", { precision: 18, scale: 2 }),
    enteredPhone: varchar("enteredPhone", { length: 40 }),
    extractedPhone: varchar("extractedPhone", { length: 40 }),
    validationStatus: mysqlEnum("validationStatus", ["pending", "matched", "mismatch", "verified"]).default("pending").notNull(),
    mismatchReason: text("mismatchReason"),
    reviewedBy: int("reviewedBy"),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ workspaceStatusIdx: index("transfer_screenshots_workspace_status_idx").on(table.workspaceId, table.validationStatus) }),
);

export const offlineQueue = mysqlTable(
  "offline_queue",
  {
    id: int("id").autoincrement().primaryKey(),
    workspaceId: int("workspaceId").notNull(),
    clientMutationId: varchar("clientMutationId", { length: 80 }).notNull(),
    operationType: varchar("operationType", { length: 80 }).notNull(),
    payload: json("payload").notNull(),
    status: mysqlEnum("status", ["queued", "processing", "synced", "failed"]).default("queued").notNull(),
    errorMessage: text("errorMessage"),
    createdBy: int("createdBy").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    syncedAt: timestamp("syncedAt"),
  },
  table => ({ mutationUnique: uniqueIndex("offline_queue_workspace_mutation_unique").on(table.workspaceId, table.clientMutationId) }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type LedgerAccount = typeof ledgerAccounts.$inferSelect;
export type Customer = typeof customers.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type LedgerEntry = typeof ledgerEntries.$inferSelect;
export type Commission = typeof commissions.$inferSelect;
export type PersonalExpense = typeof personalExpenses.$inferSelect;
export type CustomerPayable = typeof customerPayables.$inferSelect;
export type DailyClosing = typeof dailyClosings.$inferSelect;
