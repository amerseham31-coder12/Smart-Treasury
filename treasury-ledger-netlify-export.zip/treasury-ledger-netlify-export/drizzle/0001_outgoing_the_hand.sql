CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`alertType` enum('low_balance','credit_limit','reconciliation_difference','review') NOT NULL,
	`severity` enum('info','warning','critical') NOT NULL DEFAULT 'warning',
	`accountId` int,
	`customerId` int,
	`title` varchar(180) NOT NULL,
	`message` text NOT NULL,
	`isResolved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`actorUserId` int NOT NULL,
	`action` varchar(80) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` varchar(80),
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`ledgerAccountId` int NOT NULL,
	`customerCode` varchar(40) NOT NULL,
	`name` varchar(160) NOT NULL,
	`phone` varchar(40),
	`address` text,
	`creditLimit` decimal(18,2) NOT NULL DEFAULT '0.00',
	`status` enum('active','inactive','blocked') NOT NULL DEFAULT 'active',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_workspace_code_unique` UNIQUE(`workspaceId`,`customerCode`)
);
--> statement-breakpoint
CREATE TABLE `ledger_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`code` varchar(40) NOT NULL,
	`name` varchar(160) NOT NULL,
	`accountType` enum('asset','liability','equity','income','expense','receivable','payable','external') NOT NULL,
	`providerType` enum('treasury','vodafone_cash','instapay','cash','other','customer','system') NOT NULL DEFAULT 'other',
	`accountNumber` varchar(80),
	`openingBalance` decimal(18,2) NOT NULL DEFAULT '0.00',
	`lowBalanceThreshold` decimal(18,2) NOT NULL DEFAULT '0.00',
	`allowOverdraft` boolean NOT NULL DEFAULT false,
	`isActive` boolean NOT NULL DEFAULT true,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ledger_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `ledger_accounts_workspace_code_unique` UNIQUE(`workspaceId`,`code`)
);
--> statement-breakpoint
CREATE TABLE `ledger_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`transactionId` int NOT NULL,
	`accountId` int NOT NULL,
	`entryType` enum('debit','credit') NOT NULL,
	`amount` decimal(18,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ledger_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reconciliations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`accountId` int NOT NULL,
	`reconciliationDate` date NOT NULL,
	`expectedBalance` decimal(18,2) NOT NULL,
	`actualBalance` decimal(18,2) NOT NULL,
	`difference` decimal(18,2) NOT NULL,
	`reason` text,
	`notes` text,
	`status` enum('matched','unmatched','reviewed') NOT NULL DEFAULT 'unmatched',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reconciliations_id` PRIMARY KEY(`id`),
	CONSTRAINT `reconciliations_workspace_account_date_unique` UNIQUE(`workspaceId`,`accountId`,`reconciliationDate`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`transactionId` varchar(48) NOT NULL,
	`transactionType` enum('deposit','withdrawal','customer_transfer','customer_receipt','internal_transfer','expense','adjustment','reversal') NOT NULL,
	`sourceAccountId` int,
	`destinationAccountId` int,
	`customerId` int,
	`amount` decimal(18,2) NOT NULL,
	`feeAmount` decimal(18,2) NOT NULL DEFAULT '0.00',
	`netAmount` decimal(18,2) NOT NULL,
	`externalReference` varchar(120),
	`notes` text,
	`status` enum('posted','reversed','pending') NOT NULL DEFAULT 'posted',
	`originalTransactionId` int,
	`createdBy` int NOT NULL,
	`postedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_transactionId_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE TABLE `workspace_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('admin','employee','accountant') NOT NULL DEFAULT 'employee',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workspace_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `workspace_user_unique` UNIQUE(`workspaceId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `workspaces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`baseCurrency` varchar(3) NOT NULL DEFAULT 'EGP',
	`timezone` varchar(64) NOT NULL DEFAULT 'Africa/Cairo',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `workspaces_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `alerts_workspace_resolved_idx` ON `alerts` (`workspaceId`,`isResolved`);--> statement-breakpoint
CREATE INDEX `audit_logs_workspace_created_idx` ON `audit_logs` (`workspaceId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `customers_workspace_name_idx` ON `customers` (`workspaceId`,`name`);--> statement-breakpoint
CREATE INDEX `customers_workspace_phone_idx` ON `customers` (`workspaceId`,`phone`);--> statement-breakpoint
CREATE INDEX `ledger_accounts_workspace_provider_idx` ON `ledger_accounts` (`workspaceId`,`providerType`);--> statement-breakpoint
CREATE INDEX `ledger_entries_transaction_idx` ON `ledger_entries` (`transactionId`);--> statement-breakpoint
CREATE INDEX `ledger_entries_account_idx` ON `ledger_entries` (`workspaceId`,`accountId`);--> statement-breakpoint
CREATE INDEX `transactions_workspace_date_idx` ON `transactions` (`workspaceId`,`postedAt`);--> statement-breakpoint
CREATE INDEX `transactions_workspace_type_idx` ON `transactions` (`workspaceId`,`transactionType`);--> statement-breakpoint
CREATE INDEX `transactions_external_reference_idx` ON `transactions` (`workspaceId`,`externalReference`);--> statement-breakpoint
CREATE INDEX `workspace_members_workspace_idx` ON `workspace_members` (`workspaceId`);