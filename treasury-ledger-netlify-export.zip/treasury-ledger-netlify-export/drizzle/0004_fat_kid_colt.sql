ALTER TABLE `transactions` ADD `commissionType` enum('incoming','outgoing');--> statement-breakpoint
ALTER TABLE `transactions` ADD `clientMutationId` varchar(80);--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_workspace_client_mutation_unique` UNIQUE(`workspaceId`,`clientMutationId`);