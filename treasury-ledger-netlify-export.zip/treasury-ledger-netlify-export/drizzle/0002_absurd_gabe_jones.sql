CREATE TABLE `client_credentials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(80) NOT NULL,
	`passwordHash` varchar(128) NOT NULL,
	`passwordSalt` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`workspaceId` int NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `client_credentials_id` PRIMARY KEY(`id`),
	CONSTRAINT `client_credentials_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
ALTER TABLE `workspace_members` MODIFY COLUMN `role` enum('admin','employee','accountant','client') NOT NULL DEFAULT 'employee';--> statement-breakpoint
CREATE INDEX `client_credentials_workspace_idx` ON `client_credentials` (`workspaceId`);