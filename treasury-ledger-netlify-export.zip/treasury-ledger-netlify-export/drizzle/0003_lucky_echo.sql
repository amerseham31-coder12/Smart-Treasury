CREATE TABLE `commissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`transactionId` int NOT NULL,
	`commissionType` enum('incoming','outgoing') NOT NULL,
	`amount` decimal(18,2) NOT NULL,
	`accountId` int NOT NULL,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `commissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `commissions_transaction_type_unique` UNIQUE(`transactionId`,`commissionType`)
);
--> statement-breakpoint
CREATE TABLE `customer_payables` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`customerId` int NOT NULL,
	`sourceTransactionId` int NOT NULL,
	`dueAmount` decimal(18,2) NOT NULL,
	`paidAmount` decimal(18,2) NOT NULL DEFAULT '0.00',
	`dueDate` date NOT NULL,
	`paidAt` timestamp,
	`status` enum('pending','partially_paid','paid') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customer_payables_id` PRIMARY KEY(`id`),
	CONSTRAINT `customer_payables_sourceTransactionId_unique` UNIQUE(`sourceTransactionId`)
);
--> statement-breakpoint
CREATE TABLE `daily_closings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`closingDate` date NOT NULL,
	`openingBalance` decimal(18,2) NOT NULL,
	`totalInflows` decimal(18,2) NOT NULL,
	`totalOutflows` decimal(18,2) NOT NULL,
	`incomingCommissions` decimal(18,2) NOT NULL,
	`outgoingCommissions` decimal(18,2) NOT NULL,
	`personalExpenses` decimal(18,2) NOT NULL,
	`vodafoneMovements` decimal(18,2) NOT NULL,
	`customerPayables` decimal(18,2) NOT NULL,
	`closingBalance` decimal(18,2) NOT NULL,
	`transactionCount` int NOT NULL,
	`warnings` json,
	`isReopened` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `daily_closings_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_closings_workspace_date_unique` UNIQUE(`workspaceId`,`closingDate`)
);
--> statement-breakpoint
CREATE TABLE `offline_queue` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`clientMutationId` varchar(80) NOT NULL,
	`operationType` varchar(80) NOT NULL,
	`payload` json NOT NULL,
	`status` enum('queued','processing','synced','failed') NOT NULL DEFAULT 'queued',
	`errorMessage` text,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`syncedAt` timestamp,
	CONSTRAINT `offline_queue_id` PRIMARY KEY(`id`),
	CONSTRAINT `offline_queue_workspace_mutation_unique` UNIQUE(`workspaceId`,`clientMutationId`)
);
--> statement-breakpoint
CREATE TABLE `personal_expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`transactionId` int NOT NULL,
	`expenseType` varchar(100) NOT NULL,
	`description` text NOT NULL,
	`amount` decimal(18,2) NOT NULL,
	`accountId` int NOT NULL,
	`notes` text,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `personal_expenses_id` PRIMARY KEY(`id`),
	CONSTRAINT `personal_expenses_transactionId_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE TABLE `transfer_screenshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`transactionId` int NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`storageUrl` varchar(512) NOT NULL,
	`enteredAmount` decimal(18,2) NOT NULL,
	`extractedAmount` decimal(18,2),
	`enteredPhone` varchar(40),
	`extractedPhone` varchar(40),
	`validationStatus` enum('pending','matched','mismatch','verified') NOT NULL DEFAULT 'pending',
	`mismatchReason` text,
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transfer_screenshots_id` PRIMARY KEY(`id`),
	CONSTRAINT `transfer_screenshots_transactionId_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE INDEX `commissions_workspace_date_idx` ON `commissions` (`workspaceId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `customer_payables_workspace_status_idx` ON `customer_payables` (`workspaceId`,`status`);--> statement-breakpoint
CREATE INDEX `personal_expenses_workspace_date_idx` ON `personal_expenses` (`workspaceId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `transfer_screenshots_workspace_status_idx` ON `transfer_screenshots` (`workspaceId`,`validationStatus`);