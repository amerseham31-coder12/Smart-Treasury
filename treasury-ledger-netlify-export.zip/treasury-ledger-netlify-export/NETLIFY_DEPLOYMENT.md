# Treasury Ledger — Netlify Deployment

This export contains the complete current source tree: React UI, Express/tRPC API, Drizzle schema and migrations, authentication, finance rules, accounting routers, tests, styles, icons, and configuration. The UI and business logic are preserved. Netlify-specific files only add a serverless adapter and routing; they do not replace the existing accounting logic.

## Build settings

| Setting | Value |
|---|---|
| Build command | `pnpm build:netlify` |
| Publish directory | `dist/public` |
| Functions directory | `netlify/functions` |
| Node version | `22` |

The SPA fallback in `netlify.toml` keeps Wouter routes working on refresh. `/api/*` is routed to the Netlify Function, which runs the preserved Express/tRPC application.

## Required environment variables

Set these in Netlify Site configuration. Never commit real values.

### Database and sessions

- `DATABASE_URL`: production MySQL/TiDB connection string reachable from Netlify Functions.
- `JWT_SECRET`: long random session-signing secret.
- `NODE_ENV=production`.

### Manus OAuth compatibility

The current application uses Manus OAuth for the existing admin/client authentication flow. To preserve that flow outside Manus hosting, provide:

- `VITE_APP_ID`
- `OAUTH_SERVER_URL`
- `VITE_OAUTH_PORTAL_URL`
- `OWNER_OPEN_ID`
- `OWNER_NAME`

The OAuth provider must allow the Netlify site callback URL: `https://YOUR-SITE.netlify.app/api/oauth/callback`.

### Storage and optional integrations

Transfer screenshot storage currently uses the Manus Forge storage API. If screenshot upload/download features are used without Manus hosting, provide:

- `BUILT_IN_FORGE_API_URL`
- `BUILT_IN_FORGE_API_KEY`
- `VITE_FRONTEND_FORGE_API_URL`
- `VITE_FRONTEND_FORGE_API_KEY`

The data API, owner notifications, image generation, voice transcription, and map proxy helpers also use the Forge variables above when their features are invoked. If those optional features are not used, those calls remain dormant.

### Optional analytics

The original analytics placeholders remain available through the existing `VITE_ANALYTICS_ENDPOINT` and `VITE_ANALYTICS_WEBSITE_ID` variables. They are not required for accounting functionality.

## External services required

1. **MySQL/TiDB** is required for real users, accounts, balances, transactions, ledger entries, commissions, expenses, payables, daily closings, and audit history. Run the included Drizzle migrations against the new database before first use.
2. **Manus OAuth** is required if the existing username/client credential and admin OAuth flow is retained exactly as implemented. Netlify only hosts the application; it does not replace the OAuth provider.
3. **Manus Forge storage** is required for the existing transfer screenshot storage path unless `server/storage.ts` and the storage proxy are later switched to an independent S3-compatible provider.
4. **A persistent scheduler** is required for the 02:00 daily closing endpoint. Configure a scheduled external request to `POST /api/scheduled/daily-closing` with the project’s cron authentication mechanism; Netlify Functions themselves do not guarantee a resident process.

## Local verification

```bash
pnpm install
cp .env.example .env
pnpm check
pnpm test
pnpm build:netlify
```

For the existing local full-stack development server:

```bash
pnpm dev
```

## Important scope note

This package removes Manus hosting/runtime-only files from the export and provides a Netlify Functions adapter. It does **not** fabricate replacements for external authentication, database, or storage services. The accounting calculations and database schema remain the same, so the production environment must supply those services and credentials for real data operation.
