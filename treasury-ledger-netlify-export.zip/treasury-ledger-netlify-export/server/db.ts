import { and, asc, desc, eq, gte, like, or, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/mysql-core";
import { drizzle } from "drizzle-orm/mysql2";
import {
  alerts,
  auditLogs,
  customers,
  ledgerAccounts,
  ledgerEntries,
  transactions,
  users,
  workspaceMembers,
  workspaces,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { calculateBalanceCents } from "./ledger";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    values[field] = value ?? null;
    updateSet[field] = value ?? null;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function ensureWorkspaceForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const existing = await db
    .select({ workspaceId: workspaceMembers.workspaceId, workspaceName: workspaces.name, role: workspaceMembers.role })
    .from(workspaceMembers)
    .innerJoin(workspaces, eq(workspaces.id, workspaceMembers.workspaceId))
    .where(eq(workspaceMembers.userId, userId))
    .orderBy(asc(workspaceMembers.id))
    .limit(1);
  if (existing[0]) return existing[0];

  const [workspaceInsert] = await db.insert(workspaces).values({ name: "مساحة خزينة جديدة" });
  const workspaceId = Number(workspaceInsert.insertId);
  await db.insert(workspaceMembers).values({ workspaceId, userId, role: "admin" });
  return { workspaceId, workspaceName: "مساحة خزينة جديدة", role: "admin" as const };
}

export type DerivedAccount = {
  id: number;
  name: string;
  code: string;
  providerType: string;
  accountNumber: string | null;
  openingBalance: number;
  debitTotal: number;
  creditTotal: number;
  balance: number;
  lowBalanceThreshold: number;
  allowOverdraft: boolean;
};

export async function getDerivedAccounts(workspaceId: number) {
  const db = await getDb();
  if (!db) return [] as DerivedAccount[];

  const rows = await db
    .select({
      id: ledgerAccounts.id,
      name: ledgerAccounts.name,
      code: ledgerAccounts.code,
      accountType: ledgerAccounts.accountType,
      providerType: ledgerAccounts.providerType,
      accountNumber: ledgerAccounts.accountNumber,
      openingBalance: ledgerAccounts.openingBalance,
      lowBalanceThreshold: ledgerAccounts.lowBalanceThreshold,
      allowOverdraft: ledgerAccounts.allowOverdraft,
      debitTotal: sql<string>`COALESCE(SUM(CASE WHEN ${ledgerEntries.entryType} = 'debit' THEN ${ledgerEntries.amount} ELSE 0 END), 0)`,
      creditTotal: sql<string>`COALESCE(SUM(CASE WHEN ${ledgerEntries.entryType} = 'credit' THEN ${ledgerEntries.amount} ELSE 0 END), 0)`,
    })
    .from(ledgerAccounts)
    .leftJoin(ledgerEntries, and(eq(ledgerEntries.accountId, ledgerAccounts.id), eq(ledgerEntries.workspaceId, workspaceId)))
    .where(and(eq(ledgerAccounts.workspaceId, workspaceId), eq(ledgerAccounts.isActive, true)))
    .groupBy(
      ledgerAccounts.id,
      ledgerAccounts.name,
      ledgerAccounts.code,
      ledgerAccounts.accountType,
      ledgerAccounts.providerType,
      ledgerAccounts.accountNumber,
      ledgerAccounts.openingBalance,
      ledgerAccounts.lowBalanceThreshold,
      ledgerAccounts.allowOverdraft,
    );

  return rows.map(row => {
    const openingBalance = Number(row.openingBalance ?? 0);
    const debitTotal = Number(row.debitTotal ?? 0);
    const creditTotal = Number(row.creditTotal ?? 0);
    return {
      id: row.id,
      name: row.name,
      code: row.code,
      providerType: row.providerType,
      accountNumber: row.accountNumber,
      openingBalance,
      debitTotal,
      creditTotal,
      balance: calculateBalanceCents(row.accountType, openingBalance, debitTotal, creditTotal) / 100,
      lowBalanceThreshold: Number(row.lowBalanceThreshold ?? 0),
      allowOverdraft: Boolean(row.allowOverdraft),
    };
  });
}

export async function getRecentTransactions(workspaceId: number, limit = 8) {
  const db = await getDb();
  if (!db) return [];
  const source = alias(ledgerAccounts, "sourceAccount");
  const destination = alias(ledgerAccounts, "destinationAccount");
  return db
    .select({
      id: transactions.id,
      transactionId: transactions.transactionId,
      transactionType: transactions.transactionType,
      amount: transactions.amount,
      status: transactions.status,
      externalReference: transactions.externalReference,
      postedAt: transactions.postedAt,
      sourceName: source.name,
      destinationName: destination.name,
    })
    .from(transactions)
    .leftJoin(source, eq(source.id, transactions.sourceAccountId))
    .leftJoin(destination, eq(destination.id, transactions.destinationAccountId))
    .where(eq(transactions.workspaceId, workspaceId))
    .orderBy(desc(transactions.postedAt))
    .limit(limit);
}

export async function getDashboardOverview(workspaceId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const [accounts, recent] = await Promise.all([
    getDerivedAccounts(workspaceId),
    getRecentTransactions(workspaceId),
  ]);

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const [todaySummary] = await db
    .select({
      transactionCount: sql<number>`COUNT(*)`,
      incoming: sql<string>`COALESCE(SUM(CASE WHEN ${transactions.transactionType} IN ('deposit', 'customer_receipt') THEN ${transactions.amount} ELSE 0 END), 0)`,
      outgoing: sql<string>`COALESCE(SUM(CASE WHEN ${transactions.transactionType} IN ('withdrawal', 'customer_transfer', 'expense') THEN ${transactions.amount} ELSE 0 END), 0)`,
    })
    .from(transactions)
    .where(and(eq(transactions.workspaceId, workspaceId), gte(transactions.postedAt, todayStart), eq(transactions.status, "posted")));

  const activeAccounts = accounts.filter(account => ["treasury", "vodafone_cash", "instapay", "cash", "other"].includes(account.providerType));
  const totalAvailable = activeAccounts.reduce((sum, account) => sum + account.balance, 0);
  const vodafoneCash = activeAccounts.filter(account => account.providerType === "vodafone_cash").reduce((sum, account) => sum + account.balance, 0);
  const instapay = activeAccounts.filter(account => account.providerType === "instapay").reduce((sum, account) => sum + account.balance, 0);
  const treasury = activeAccounts.filter(account => account.providerType === "treasury").reduce((sum, account) => sum + account.balance, 0);
  const lowBalanceAlerts = accounts
    .filter(account => account.lowBalanceThreshold > 0 && account.balance < account.lowBalanceThreshold)
    .map(account => ({
      id: `account-${account.id}`,
      type: "low_balance" as const,
      title: "رصيد حساب منخفض",
      message: `${account.name} أقل من الحد المحدد`,
      severity: account.balance <= 0 ? "critical" as const : "warning" as const,
    }));

  const openAlerts = await db
    .select({ id: alerts.id, alertType: alerts.alertType, title: alerts.title, message: alerts.message, severity: alerts.severity })
    .from(alerts)
    .where(and(eq(alerts.workspaceId, workspaceId), eq(alerts.isResolved, false)))
    .orderBy(desc(alerts.createdAt))
    .limit(6);

  return {
    workspaceId,
    currency: "EGP",
    balances: {
      treasury,
      vodafoneCash,
      instapay,
      totalAccounts: totalAvailable,
      totalIncoming: Number(todaySummary?.incoming ?? 0),
      totalOutgoing: Number(todaySummary?.outgoing ?? 0),
      netAvailable: totalAvailable,
    },
    today: {
      transactionCount: Number(todaySummary?.transactionCount ?? 0),
      incoming: Number(todaySummary?.incoming ?? 0),
      outgoing: Number(todaySummary?.outgoing ?? 0),
    },
    accounts,
    recent,
    alerts: [...lowBalanceAlerts, ...openAlerts].slice(0, 6),
  };
}

export async function createAuditLog(input: {
  workspaceId: number;
  actorUserId: number;
  action: string;
  entityType: string;
  entityId?: string;
  metadata?: unknown;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(auditLogs).values({
    workspaceId: input.workspaceId,
    actorUserId: input.actorUserId,
    action: input.action,
    entityType: input.entityType,
    entityId: input.entityId,
    metadata: input.metadata,
  });
}

export async function getWorkspaceRole(userId: number, workspaceId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({ role: workspaceMembers.role })
    .from(workspaceMembers)
    .where(and(eq(workspaceMembers.userId, userId), eq(workspaceMembers.workspaceId, workspaceId)))
    .limit(1);
  return result[0]?.role;
}

export async function searchTransactions(workspaceId: number, query?: string) {
  const db = await getDb();
  if (!db) return [];
  const filters = [eq(transactions.workspaceId, workspaceId)];
  if (query?.trim()) {
    const value = `%${query.trim()}%`;
    filters.push(or(like(transactions.transactionId, value), like(transactions.externalReference, value)) as never);
  }
  return db.select().from(transactions).where(and(...filters)).orderBy(desc(transactions.postedAt)).limit(50);
}
