import { TRPCError } from "@trpc/server";
import { and, desc, eq, gte, inArray, or, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/mysql-core";
import { z } from "zod";
import { auditLogs, commissions, customers, customerPayables, ledgerAccounts, ledgerEntries, personalExpenses, transactions } from "../../drizzle/schema";
import { getDb } from "../db";
import { adminProcedure, workspaceProcedure } from "./_shared";
import { router } from "../_core/trpc";
import { assertBalanced, calculateBalanceCents, centsToMoney, moneyToCents } from "../ledger";
import { getVodafoneLimitState } from "../finance/rules";

const transactionType = z.enum([
  "deposit",
  "withdrawal",
  "customer_transfer",
  "customer_receipt",
  "internal_transfer",
  "expense",
  "adjustment",
]);

const amountSchema = z.string().regex(/^\d{1,16}(\.\d{1,2})?$/, "المبلغ يجب أن يكون رقمًا موجبًا بدقة منزلتين");

function transactionCode() {
  return `TRX-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
}

async function ensureSystemAccount(tx: any, workspaceId: number, code: string, name: string, accountType: "income" | "expense" | "external") {
  const existing = await tx
    .select({ id: ledgerAccounts.id })
    .from(ledgerAccounts)
    .where(and(eq(ledgerAccounts.workspaceId, workspaceId), eq(ledgerAccounts.code, code)))
    .limit(1);
  if (existing[0]) return existing[0].id;
  const [inserted] = await tx.insert(ledgerAccounts).values({
    workspaceId,
    code,
    name,
    accountType,
    providerType: "system",
    allowOverdraft: true,
  });
  return Number(inserted.insertId);
}

async function getAccountState(tx: any, workspaceId: number, accountId: number) {
  const [account] = await tx
    .select({
      id: ledgerAccounts.id,
      accountType: ledgerAccounts.accountType,
      providerType: ledgerAccounts.providerType,
      isActive: ledgerAccounts.isActive,
      allowOverdraft: ledgerAccounts.allowOverdraft,
      openingBalance: ledgerAccounts.openingBalance,
    })
    .from(ledgerAccounts)
    .where(and(eq(ledgerAccounts.workspaceId, workspaceId), eq(ledgerAccounts.id, accountId)))
    .limit(1);
  if (!account) throw new TRPCError({ code: "NOT_FOUND", message: "الحساب المالي غير موجود" });
  if (!account.isActive) throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن استخدام حساب غير فعال" });

  const [totals] = await tx
    .select({
      debit: sql<string>`COALESCE(SUM(CASE WHEN ${ledgerEntries.entryType} = 'debit' THEN ${ledgerEntries.amount} ELSE 0 END), 0)`,
      credit: sql<string>`COALESCE(SUM(CASE WHEN ${ledgerEntries.entryType} = 'credit' THEN ${ledgerEntries.amount} ELSE 0 END), 0)`,
    })
    .from(ledgerEntries)
    .where(and(eq(ledgerEntries.workspaceId, workspaceId), eq(ledgerEntries.accountId, accountId)));
  const balanceCents = calculateBalanceCents(account.accountType, account.openingBalance ?? "0", totals?.debit ?? "0", totals?.credit ?? "0");
  return { ...account, balanceCents };
}

export const transactionsRouter = router({
  list: workspaceProcedure.query(({ ctx }) => {
    return getDb().then(db => {
      if (!db) return [];
      const source = alias(ledgerAccounts, "reportSourceAccount");
      const destination = alias(ledgerAccounts, "reportDestinationAccount");
      return db.select({
        id: transactions.id,
        transactionId: transactions.transactionId,
        transactionType: transactions.transactionType,
        amount: transactions.amount,
        feeAmount: transactions.feeAmount,
        netAmount: transactions.netAmount,
        status: transactions.status,
        externalReference: transactions.externalReference,
        notes: transactions.notes,
        sourceName: source.name,
        destinationName: destination.name,
        postedAt: transactions.postedAt,
      }).from(transactions)
        .leftJoin(source, eq(source.id, transactions.sourceAccountId))
        .leftJoin(destination, eq(destination.id, transactions.destinationAccountId))
        .where(eq(transactions.workspaceId, ctx.workspace.workspaceId))
        .orderBy(desc(transactions.postedAt)).limit(100);
    });
  }),

  create: workspaceProcedure
    .input(z.object({
      transactionType,
      sourceAccountId: z.number().int().positive().optional(),
      destinationAccountId: z.number().int().positive().optional(),
      customerId: z.number().int().positive().optional(),
      amount: amountSchema,
      feeAmount: amountSchema.default("0.00"),
      commissionType: z.enum(["incoming", "outgoing"]).optional(),
      clientMutationId: z.string().min(8).max(80).optional(),
      expenseType: z.string().max(100).optional(),
      expenseDescription: z.string().max(1000).optional(),
      externalReference: z.string().max(120).optional(),
      notes: z.string().max(2000).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.workspace.role === "client") {
        throw new TRPCError({ code: "FORBIDDEN", message: "حساب العميل للعرض فقط ولا يمكنه إنشاء عمليات" });
      }
      const amountCents = moneyToCents(input.amount);
      const feeCents = moneyToCents(input.feeAmount);
      if (amountCents <= 0) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب أن يكون المبلغ أكبر من صفر" });
      if (feeCents < 0) throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن أن تكون الرسوم سالبة" });
      if (input.sourceAccountId && input.sourceAccountId === input.destinationAccountId) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن التحويل إلى الحساب نفسه" });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db.transaction(async tx => {
        if (input.clientMutationId) {
          const [existing] = await tx.select({ id: transactions.id, transactionId: transactions.transactionId })
            .from(transactions)
            .where(and(eq(transactions.workspaceId, ctx.workspace.workspaceId), eq(transactions.clientMutationId, input.clientMutationId)))
            .limit(1);
          if (existing) return { transactionId: existing.id, externalTransactionId: existing.transactionId, status: "posted" as const, duplicate: true as const };
        }
        let sourceAccountId = input.sourceAccountId;
        let destinationAccountId = input.destinationAccountId;

        if (input.customerId) {
          const [customer] = await tx.select({ ledgerAccountId: customers.ledgerAccountId, status: customers.status })
            .from(customers)
            .where(and(eq(customers.workspaceId, ctx.workspace.workspaceId), eq(customers.id, input.customerId)))
            .limit(1);
          if (!customer || customer.status !== "active") throw new TRPCError({ code: "BAD_REQUEST", message: "العميل غير موجود أو غير فعال" });
          if (input.transactionType === "customer_transfer") destinationAccountId = customer.ledgerAccountId;
          if (input.transactionType === "customer_receipt") sourceAccountId = customer.ledgerAccountId;
        }

        if (["deposit", "customer_receipt"].includes(input.transactionType) && !sourceAccountId) {
          sourceAccountId = await ensureSystemAccount(tx, ctx.workspace.workspaceId, "EXTERNAL-IN", "مقابل إيداعات خارجية", "external");
        }
        if (["withdrawal", "expense"].includes(input.transactionType) && !destinationAccountId) {
          const code = input.transactionType === "expense" ? "EXPENSE-GENERAL" : "EXTERNAL-OUT";
          const name = input.transactionType === "expense" ? "مصروفات عامة" : "مقابل مسحوبات خارجية";
          destinationAccountId = await ensureSystemAccount(tx, ctx.workspace.workspaceId, code, name, input.transactionType === "expense" ? "expense" : "external");
        }

        if (!sourceAccountId || !destinationAccountId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "يجب تحديد الحساب المصدر والحساب المستلم" });
        }

        const source = await getAccountState(tx, ctx.workspace.workspaceId, sourceAccountId);
        const destination = await getAccountState(tx, ctx.workspace.workspaceId, destinationAccountId);
        if (!source.allowOverdraft && source.balanceCents < amountCents + feeCents) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "الرصيد المتاح في الحساب المصدر لا يكفي" });
        }

        const vodafoneAccount = [source, destination].find(account => account.providerType === "vodafone_cash");
        if (vodafoneAccount) {
          const todayStart = new Date();
          todayStart.setHours(0, 0, 0, 0);
          const [usage] = await tx.select({ used: sql<string>`COALESCE(SUM(${transactions.amount}), 0)` })
            .from(transactions)
            .where(and(
              eq(transactions.workspaceId, ctx.workspace.workspaceId),
              eq(transactions.status, "posted"),
              gte(transactions.postedAt, todayStart),
              or(eq(transactions.sourceAccountId, vodafoneAccount.id), eq(transactions.destinationAccountId, vodafoneAccount.id)),
            ));
          const limitState = getVodafoneLimitState(moneyToCents(String(usage?.used ?? "0")), amountCents);
          if (limitState.exceedsLimit && ctx.workspace.role !== "admin") {
            throw new TRPCError({ code: "FORBIDDEN", message: `تجاوز الحد اليومي لرقم Vodafone Cash. الاستخدام المتوقع ${centsToMoney(limitState.projectedCents)} من ${centsToMoney(20_000_000)}.` });
          }
        }

        const feeAccountId = feeCents > 0
          ? await ensureSystemAccount(tx, ctx.workspace.workspaceId, "FEE-INCOME", "إيرادات الرسوم", "income")
          : null;
        const [created] = await tx.insert(transactions).values({
          workspaceId: ctx.workspace.workspaceId,
          transactionId: transactionCode(),
          transactionType: input.transactionType,
          sourceAccountId,
          destinationAccountId,
          customerId: input.customerId,
          amount: centsToMoney(amountCents),
          feeAmount: centsToMoney(feeCents),
          commissionType: input.commissionType,
          netAmount: centsToMoney(amountCents - feeCents),
          clientMutationId: input.clientMutationId,
          externalReference: input.externalReference,
          notes: input.notes,
          createdBy: ctx.user.id,
        });
        const transactionDbId = Number(created.insertId);
        const entries = [
          { workspaceId: ctx.workspace.workspaceId, transactionId: transactionDbId, accountId: sourceAccountId, entryType: "credit" as const, amount: centsToMoney(amountCents + feeCents) },
          { workspaceId: ctx.workspace.workspaceId, transactionId: transactionDbId, accountId: destinationAccountId, entryType: "debit" as const, amount: centsToMoney(amountCents) },
        ];
        if (feeAccountId) entries.push({ workspaceId: ctx.workspace.workspaceId, transactionId: transactionDbId, accountId: feeAccountId, entryType: "credit" as const, amount: centsToMoney(feeCents) });
        assertBalanced(entries);
        await tx.insert(ledgerEntries).values(entries);
        if (feeCents > 0) {
          await tx.insert(commissions).values({
            workspaceId: ctx.workspace.workspaceId,
            transactionId: transactionDbId,
            commissionType: input.commissionType ?? "outgoing",
            amount: centsToMoney(feeCents),
            accountId: input.commissionType === "incoming" ? destinationAccountId : sourceAccountId,
            createdBy: ctx.user.id,
          });
        }
        if (input.transactionType === "expense") {
          await tx.insert(personalExpenses).values({
            workspaceId: ctx.workspace.workspaceId,
            transactionId: transactionDbId,
            expenseType: input.expenseType ?? "عام",
            description: input.expenseDescription ?? input.notes ?? "مصروف شخصي",
            amount: centsToMoney(amountCents),
            accountId: sourceAccountId,
            notes: input.notes,
            createdBy: ctx.user.id,
          });
        }
        if (input.transactionType === "customer_transfer" && input.customerId) {
          await tx.insert(customerPayables).values({
            workspaceId: ctx.workspace.workspaceId,
            customerId: input.customerId,
            sourceTransactionId: transactionDbId,
            dueAmount: centsToMoney(amountCents),
            dueDate: new Date(),
          });
        }
        await tx.insert(auditLogs).values({
          workspaceId: ctx.workspace.workspaceId,
          actorUserId: ctx.user.id,
          action: "transaction.posted",
          entityType: "transaction",
          entityId: String(transactionDbId),
          metadata: { transactionType: input.transactionType, amount: input.amount },
        });
        return { transactionId: transactionDbId, status: "posted" as const, duplicate: false as const };
      });
    }),

  reverse: adminProcedure
    .input(z.object({ transactionId: z.number().int().positive(), reason: z.string().min(3).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db.transaction(async tx => {
        const [original] = await tx.select().from(transactions)
          .where(and(eq(transactions.workspaceId, ctx.workspace.workspaceId), eq(transactions.id, input.transactionId)))
          .limit(1);
        if (!original) throw new TRPCError({ code: "NOT_FOUND", message: "العملية الأصلية غير موجودة" });
        if (original.status !== "posted") throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن عكس عملية غير منشورة" });
        const [existingReversal] = await tx.select({ id: transactions.id }).from(transactions)
          .where(and(eq(transactions.workspaceId, ctx.workspace.workspaceId), eq(transactions.originalTransactionId, original.id)))
          .limit(1);
        if (existingReversal) throw new TRPCError({ code: "BAD_REQUEST", message: "تم عكس هذه العملية من قبل" });

        const originalEntries = await tx.select().from(ledgerEntries).where(eq(ledgerEntries.transactionId, original.id));
        if (originalEntries.length < 2) throw new TRPCError({ code: "BAD_REQUEST", message: "العملية الأصلية لا تحتوي على قيود متوازنة" });
        const [created] = await tx.insert(transactions).values({
          workspaceId: ctx.workspace.workspaceId,
          transactionId: transactionCode(),
          transactionType: "reversal",
          sourceAccountId: original.destinationAccountId,
          destinationAccountId: original.sourceAccountId,
          customerId: original.customerId,
          amount: original.amount,
          feeAmount: original.feeAmount,
          netAmount: original.netAmount,
          externalReference: `REVERSAL:${original.transactionId}`,
          notes: input.reason,
          originalTransactionId: original.id,
          createdBy: ctx.user.id,
        });
        const reversalId = Number(created.insertId);
        await tx.insert(ledgerEntries).values(originalEntries.map(entry => ({
          workspaceId: ctx.workspace.workspaceId,
          transactionId: reversalId,
          accountId: entry.accountId,
          entryType: entry.entryType === "debit" ? "credit" as const : "debit" as const,
          amount: entry.amount,
        })));
        await tx.update(transactions).set({ status: "reversed" }).where(eq(transactions.id, original.id));
        await tx.insert(auditLogs).values({
          workspaceId: ctx.workspace.workspaceId,
          actorUserId: ctx.user.id,
          action: "transaction.reversed",
          entityType: "transaction",
          entityId: String(original.id),
          metadata: { reversalId, reason: input.reason },
        });
        return { reversalId, status: "posted" as const };
      });
    }),
});
