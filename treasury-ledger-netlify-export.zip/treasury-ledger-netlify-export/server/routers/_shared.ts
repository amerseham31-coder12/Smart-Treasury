import { TRPCError } from "@trpc/server";
import { protectedProcedure } from "../_core/trpc";
import { ensureWorkspaceForUser } from "../db";

export const workspaceProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  const workspace = await ensureWorkspaceForUser(ctx.user.id);
  return next({ ctx: { ...ctx, workspace } });
});

export const adminProcedure = workspaceProcedure.use(async ({ ctx, next }) => {
  if (ctx.workspace.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية تنفيذ هذا الإجراء" });
  }
  return next();
});

export const accountantProcedure = workspaceProcedure.use(async ({ ctx, next }) => {
  if (!["admin", "accountant"].includes(ctx.workspace.role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "هذا الإجراء متاح للمحاسب أو المدير فقط" });
  }
  return next();
});
