import { z } from "zod";
import { getDashboardOverview, searchTransactions } from "../db";
import { workspaceProcedure } from "./_shared";
import { router } from "../_core/trpc";

export const dashboardRouter = router({
  overview: workspaceProcedure.query(({ ctx }) => getDashboardOverview(ctx.workspace.workspaceId)),
  search: workspaceProcedure
    .input(z.object({ query: z.string().max(120).optional() }))
    .query(({ ctx, input }) => searchTransactions(ctx.workspace.workspaceId, input.query)),
});
