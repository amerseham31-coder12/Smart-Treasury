import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { auditLogs, ledgerAccounts } from "../../drizzle/schema";
import { getDb, getDerivedAccounts } from "../db";
import { adminProcedure, workspaceProcedure } from "./_shared";
import { router } from "../_core/trpc";

const accountType = z.enum(["asset", "liability", "equity", "income", "expense", "receivable", "payable", "external"]);
const providerType = z.enum(["treasury", "vodafone_cash", "instapay", "cash", "other"]);
const moneyInput = z.string().regex(/^\d{1,16}(\.\d{1,2})?$/, "قيمة مالية غير صحيحة");

export const accountsRouter = router({
  list: workspaceProcedure.query(({ ctx }) => getDerivedAccounts(ctx.workspace.workspaceId)),
  create: adminProcedure
    .input(z.object({
      code: z.string().min(2).max(40).regex(/^[A-Z0-9_-]+$/, "استخدم أحرفًا إنجليزية كبيرة وأرقامًا فقط في الكود"),
      name: z.string().min(2).max(160),
      accountType,
      providerType,
      accountNumber: z.string().max(80).optional(),
      openingBalance: moneyInput.default("0.00"),
      lowBalanceThreshold: moneyInput.default("0.00"),
      allowOverdraft: z.boolean().default(false),
      notes: z.string().max(2000).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db.transaction(async tx => {
        const [created] = await tx.insert(ledgerAccounts).values({
          workspaceId: ctx.workspace.workspaceId,
          code: input.code,
          name: input.name,
          accountType: input.accountType,
          providerType: input.providerType,
          accountNumber: input.accountNumber,
          openingBalance: input.openingBalance,
          lowBalanceThreshold: input.lowBalanceThreshold,
          allowOverdraft: input.allowOverdraft,
          notes: input.notes,
        });
        const accountId = Number(created.insertId);
        await tx.insert(auditLogs).values({
          workspaceId: ctx.workspace.workspaceId,
          actorUserId: ctx.user.id,
          action: "account.created",
          entityType: "ledger_account",
          entityId: String(accountId),
          metadata: { code: input.code, providerType: input.providerType },
        });
        return { accountId };
      });
    }),
  deactivate: adminProcedure
    .input(z.object({ accountId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      await db.update(ledgerAccounts).set({ isActive: false }).where(and(eq(ledgerAccounts.id, input.accountId), eq(ledgerAccounts.workspaceId, ctx.workspace.workspaceId)));
      return { success: true } as const;
    }),
});
