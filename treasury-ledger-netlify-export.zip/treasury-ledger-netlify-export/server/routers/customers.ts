import { TRPCError } from "@trpc/server";
import { and, asc, eq } from "drizzle-orm";
import { z } from "zod";
import { auditLogs, customers, ledgerAccounts } from "../../drizzle/schema";
import { getDb, getDerivedAccounts } from "../db";
import { adminProcedure, workspaceProcedure } from "./_shared";
import { router } from "../_core/trpc";

const moneyInput = z.string().regex(/^\d{1,16}(\.\d{1,2})?$/, "قيمة مالية غير صحيحة");

export const customersRouter = router({
  list: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const [rows, accounts] = await Promise.all([
      db.select().from(customers).where(eq(customers.workspaceId, ctx.workspace.workspaceId)).orderBy(asc(customers.name)),
      getDerivedAccounts(ctx.workspace.workspaceId),
    ]);
    const balances = new Map(accounts.map(account => [account.id, account.balance]));
    return rows.map(customer => ({ ...customer, balance: balances.get(customer.ledgerAccountId) ?? 0 }));
  }),
  create: adminProcedure
    .input(z.object({
      customerCode: z.string().min(2).max(40).regex(/^[A-Z0-9_-]+$/, "استخدم أحرفًا إنجليزية كبيرة وأرقامًا فقط في الكود"),
      name: z.string().min(2).max(160),
      phone: z.string().max(40).optional(),
      address: z.string().max(1000).optional(),
      creditLimit: moneyInput.default("0.00"),
      notes: z.string().max(2000).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db.transaction(async tx => {
        const [account] = await tx.insert(ledgerAccounts).values({
          workspaceId: ctx.workspace.workspaceId,
          code: `CUST-${input.customerCode}`,
          name: `حساب العميل · ${input.name}`,
          accountType: "receivable",
          providerType: "customer",
          allowOverdraft: true,
        });
        const ledgerAccountId = Number(account.insertId);
        const [customer] = await tx.insert(customers).values({
          workspaceId: ctx.workspace.workspaceId,
          ledgerAccountId,
          customerCode: input.customerCode,
          name: input.name,
          phone: input.phone,
          address: input.address,
          creditLimit: input.creditLimit,
          notes: input.notes,
        });
        const customerId = Number(customer.insertId);
        await tx.insert(auditLogs).values({
          workspaceId: ctx.workspace.workspaceId,
          actorUserId: ctx.user.id,
          action: "customer.created",
          entityType: "customer",
          entityId: String(customerId),
          metadata: { customerCode: input.customerCode },
        });
        return { customerId };
      });
    }),
});
