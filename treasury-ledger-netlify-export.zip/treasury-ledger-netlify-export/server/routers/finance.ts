import { and, desc, eq, gte, lt, sql } from "drizzle-orm";
import { commissions, customerPayables, customers, dailyClosings, ledgerAccounts, personalExpenses, transactions } from "../../drizzle/schema";
import { getDb, getDerivedAccounts } from "../db";
import { getVodafoneLimitState } from "../finance/rules";
import { adminProcedure, workspaceProcedure } from "./_shared";
import { router } from "../_core/trpc";
import { z } from "zod";

function currentDayStart() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}

export const financeRouter = router({
  vodafone: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const start = currentDayStart();
    const accounts = (await getDerivedAccounts(ctx.workspace.workspaceId)).filter(account => account.providerType === "vodafone_cash");
    return Promise.all(accounts.map(async account => {
      const [usage] = await db.select({ used: sql<string>`COALESCE(SUM(${transactions.amount}),0)` }).from(transactions)
        .where(and(eq(transactions.workspaceId, ctx.workspace.workspaceId), eq(transactions.status, "posted"), gte(transactions.postedAt, start), sql`(${transactions.sourceAccountId} = ${account.id} OR ${transactions.destinationAccountId} = ${account.id})`));
      const limit = getVodafoneLimitState(Math.round(Number(usage?.used ?? 0) * 100));
      return { ...account, dailyUsed: limit.usedCents / 100, dailyLimit: 200_000, remaining: limit.remainingCents / 100, usagePercent: limit.usagePercent, status: limit.status };
    }));
  }),
  commissions: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { rows: [], totals: { incoming: 0, outgoing: 0, net: 0 } };
    const rows = await db.select({
      id: commissions.id,
      transactionId: transactions.transactionId,
      transactionDbId: transactions.id,
      transactionType: transactions.transactionType,
      transactionAmount: transactions.amount,
      commissionType: commissions.commissionType,
      amount: commissions.amount,
      accountName: ledgerAccounts.name,
      createdAt: commissions.createdAt,
    }).from(commissions).innerJoin(transactions, eq(transactions.id, commissions.transactionId)).innerJoin(ledgerAccounts, eq(ledgerAccounts.id, commissions.accountId))
      .where(eq(commissions.workspaceId, ctx.workspace.workspaceId)).orderBy(desc(commissions.createdAt)).limit(250);
    const incoming = rows.filter(row => row.commissionType === "incoming").reduce((sum, row) => sum + Number(row.amount), 0);
    const outgoing = rows.filter(row => row.commissionType === "outgoing").reduce((sum, row) => sum + Number(row.amount), 0);
    return { rows, totals: { incoming, outgoing, net: incoming - outgoing } };
  }),
  expenses: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { rows: [], total: 0 };
    const rows = await db.select({ id: personalExpenses.id, expenseType: personalExpenses.expenseType, description: personalExpenses.description, amount: personalExpenses.amount, accountName: ledgerAccounts.name, createdAt: personalExpenses.createdAt, transactionId: transactions.transactionId })
      .from(personalExpenses).innerJoin(ledgerAccounts, eq(ledgerAccounts.id, personalExpenses.accountId)).innerJoin(transactions, eq(transactions.id, personalExpenses.transactionId))
      .where(eq(personalExpenses.workspaceId, ctx.workspace.workspaceId)).orderBy(desc(personalExpenses.createdAt)).limit(250);
    return { rows, total: rows.reduce((sum, row) => sum + Number(row.amount), 0) };
  }),
  payables: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { rows: [], totals: { due: 0, paid: 0, remaining: 0 } };
    const rows = await db.select({ id: customerPayables.id, customerName: customers.name, customerCode: customers.customerCode, sourceTransactionId: transactions.transactionId, dueAmount: customerPayables.dueAmount, paidAmount: customerPayables.paidAmount, dueDate: customerPayables.dueDate, paidAt: customerPayables.paidAt, status: customerPayables.status })
      .from(customerPayables).innerJoin(customers, eq(customers.id, customerPayables.customerId)).innerJoin(transactions, eq(transactions.id, customerPayables.sourceTransactionId))
      .where(eq(customerPayables.workspaceId, ctx.workspace.workspaceId)).orderBy(desc(customerPayables.createdAt));
    const due = rows.reduce((sum, row) => sum + Number(row.dueAmount), 0);
    const paid = rows.reduce((sum, row) => sum + Number(row.paidAmount), 0);
    return { rows, totals: { due, paid, remaining: due - paid } };
  }),
  closings: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(dailyClosings).where(eq(dailyClosings.workspaceId, ctx.workspace.workspaceId)).orderBy(desc(dailyClosings.closingDate)).limit(90);
  }),
  masterReport: workspaceProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;
    const [accounts, commissionTotals, expenseTotals, payableTotals, transferTotals, reviewTotals] = await Promise.all([
      getDerivedAccounts(ctx.workspace.workspaceId),
      db.select({ incoming: sql<string>`COALESCE(SUM(CASE WHEN ${commissions.commissionType}='incoming' THEN ${commissions.amount} ELSE 0 END),0)`, outgoing: sql<string>`COALESCE(SUM(CASE WHEN ${commissions.commissionType}='outgoing' THEN ${commissions.amount} ELSE 0 END),0)` }).from(commissions).where(eq(commissions.workspaceId, ctx.workspace.workspaceId)),
      db.select({ total: sql<string>`COALESCE(SUM(${personalExpenses.amount}),0)` }).from(personalExpenses).where(eq(personalExpenses.workspaceId, ctx.workspace.workspaceId)),
      db.select({ due: sql<string>`COALESCE(SUM(${customerPayables.dueAmount}),0)`, paid: sql<string>`COALESCE(SUM(${customerPayables.paidAmount}),0)` }).from(customerPayables).where(eq(customerPayables.workspaceId, ctx.workspace.workspaceId)),
      db.select({ count: sql<number>`COUNT(*)`, inflows: sql<string>`COALESCE(SUM(CASE WHEN ${transactions.transactionType} IN ('deposit','customer_receipt') THEN ${transactions.amount} ELSE 0 END),0)`, outflows: sql<string>`COALESCE(SUM(CASE WHEN ${transactions.transactionType} IN ('withdrawal','customer_transfer','expense') THEN ${transactions.amount} ELSE 0 END),0)` }).from(transactions).where(and(eq(transactions.workspaceId, ctx.workspace.workspaceId), eq(transactions.status, "posted"))),
      db.select({ count: sql<number>`COUNT(*)` }).from(transactions).where(and(eq(transactions.workspaceId, ctx.workspace.workspaceId), sql`${transactions.status} <> 'posted'`)),
    ]);
    const commission = commissionTotals[0] ?? { incoming: "0", outgoing: "0" };
    const payable = payableTotals[0] ?? { due: "0", paid: "0" };
    const active = accounts.filter(account => ["treasury", "vodafone_cash", "instapay", "cash", "other"].includes(account.providerType));
    return {
      treasury: { currentBalance: active.reduce((sum, account) => sum + account.balance, 0), inflows: Number(transferTotals[0]?.inflows ?? 0), outflows: Number(transferTotals[0]?.outflows ?? 0), personalExpenses: Number(expenseTotals[0]?.total ?? 0) },
      vodafone: active.filter(account => account.providerType === "vodafone_cash"),
      customers: { due: Number(payable.due), paid: Number(payable.paid), remaining: Number(payable.due) - Number(payable.paid) },
      transfers: { count: Number(transferTotals[0]?.count ?? 0), inflows: Number(transferTotals[0]?.inflows ?? 0), outflows: Number(transferTotals[0]?.outflows ?? 0), needsReview: Number(reviewTotals[0]?.count ?? 0) },
      commissions: { incoming: Number(commission.incoming), outgoing: Number(commission.outgoing), net: Number(commission.incoming) - Number(commission.outgoing) },
      expenses: { total: Number(expenseTotals[0]?.total ?? 0) },
    };
  }),
  reopenClosing: adminProcedure.input(z.object({ closingId: z.number().int().positive(), reason: z.string().min(3).max(500) })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    await db.update(dailyClosings).set({ isReopened: true }).where(and(eq(dailyClosings.id, input.closingId), eq(dailyClosings.workspaceId, ctx.workspace.workspaceId)));
    return { success: true as const };
  }),
});
