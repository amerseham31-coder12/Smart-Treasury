export const VODAFONE_DAILY_LIMIT_CENTS = 20_000_000;
export const VODAFONE_WARNING_CENTS = 18_000_000;

export type LimitStatus = "normal" | "near_limit" | "limit_reached";

export function getVodafoneLimitState(usedCents: number, proposedCents = 0) {
  const projected = usedCents + proposedCents;
  const status: LimitStatus = projected >= VODAFONE_DAILY_LIMIT_CENTS
    ? "limit_reached"
    : projected >= VODAFONE_WARNING_CENTS
      ? "near_limit"
      : "normal";
  return {
    usedCents,
    projectedCents: projected,
    remainingCents: Math.max(0, VODAFONE_DAILY_LIMIT_CENTS - projected),
    usagePercent: (projected / VODAFONE_DAILY_LIMIT_CENTS) * 100,
    status,
    exceedsLimit: projected > VODAFONE_DAILY_LIMIT_CENTS,
  };
}

export function commissionNetCents(incomingCents: number, outgoingCents: number) {
  return incomingCents - outgoingCents;
}

export type PayableStatus = "pending" | "partially_paid" | "paid";

export function getPayableStatus(dueCents: number, paidCents: number): PayableStatus {
  if (paidCents >= dueCents) return "paid";
  if (paidCents > 0) return "partially_paid";
  return "pending";
}

export function assertPayablePayment(dueCents: number, paidCents: number, paymentCents: number) {
  if (paymentCents <= 0) throw new Error("Payment must be positive");
  if (paidCents + paymentCents > dueCents) throw new Error("Payment exceeds payable balance");
}

export function dailyClosingBalance(openingCents: number, inflowsCents: number, outflowsCents: number, incomingCommissionCents: number, outgoingCommissionCents: number, expensesCents: number) {
  return openingCents + inflowsCents - outflowsCents + incomingCommissionCents - outgoingCommissionCents - expensesCents;
}
