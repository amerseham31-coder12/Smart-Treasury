import { describe, expect, it } from "vitest";
import { assertPayablePayment, commissionNetCents, dailyClosingBalance, getPayableStatus, getVodafoneLimitState } from "./rules";

describe("Vodafone Cash daily limit", () => {
  it("warns at 180,000 and blocks projected values over 200,000", () => {
    expect(getVodafoneLimitState(18_000_000).status).toBe("near_limit");
    expect(getVodafoneLimitState(20_000_000).status).toBe("limit_reached");
    expect(getVodafoneLimitState(19_900_000, 200_000).exceedsLimit).toBe(true);
  });
});

describe("commission integrity", () => {
  it("calculates net commission without floating point arithmetic", () => {
    expect(commissionNetCents(125, 40)).toBe(85);
  });
});

describe("customer payables", () => {
  it("tracks pending, partial, and paid states", () => {
    expect(getPayableStatus(1000, 0)).toBe("pending");
    expect(getPayableStatus(1000, 400)).toBe("partially_paid");
    expect(getPayableStatus(1000, 1000)).toBe("paid");
    expect(() => assertPayablePayment(1000, 900, 200)).toThrow();
  });
});

describe("daily closing", () => {
  it("reconciles opening balance with all day movements", () => {
    expect(dailyClosingBalance(10_000, 5_000, 2_000, 200, 50, 100)).toBe(13_050);
  });
});
