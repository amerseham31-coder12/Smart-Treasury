import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./password";

describe("client password credentials", () => {
  it("hashes and verifies a password without storing the original value", () => {
    const result = hashPassword("ClientPass123!");
    expect(result.hash).not.toBe("ClientPass123!");
    expect(result.salt).toHaveLength(32);
    expect(result.hash).toHaveLength(128);
    expect(verifyPassword("ClientPass123!", result.salt, result.hash)).toBe(true);
    expect(verifyPassword("wrong-password", result.salt, result.hash)).toBe(false);
  });
});
