export type LedgerLine = { entryType: "debit" | "credit"; amount: string | number };

export function moneyToCents(value: string | number | null | undefined) {
  const normalized = String(value ?? "0").trim();
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) throw new Error("Invalid monetary value");
  const [whole, fraction = ""] = normalized.split(".");
  return Number(whole) * 100 + Number((fraction + "00").slice(0, 2));
}

export function centsToMoney(cents: number) {
  return (cents / 100).toFixed(2);
}

export function calculateBalanceCents(accountType: string, openingBalance: string | number, debitTotal: string | number, creditTotal: string | number) {
  const opening = moneyToCents(openingBalance);
  const debits = moneyToCents(debitTotal);
  const credits = moneyToCents(creditTotal);
  const creditNature = ["liability", "equity", "income", "payable"].includes(accountType);
  return opening + (creditNature ? credits - debits : debits - credits);
}

export function assertBalanced(lines: LedgerLine[]) {
  const debits = lines.filter(line => line.entryType === "debit").reduce((sum, line) => sum + moneyToCents(line.amount), 0);
  const credits = lines.filter(line => line.entryType === "credit").reduce((sum, line) => sum + moneyToCents(line.amount), 0);
  if (debits <= 0 || debits !== credits) throw new Error("Ledger entries must have equal positive debit and credit totals");
  return { debits, credits };
}
