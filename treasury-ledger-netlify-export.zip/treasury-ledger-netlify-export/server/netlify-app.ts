import "dotenv/config";
import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./_core/oauth";
import { registerStorageProxy } from "./_core/storageProxy";
import { appRouter } from "./routers";
import { createContext } from "./_core/context";
import { sdk } from "./_core/sdk";
import { closeAllWorkspaces } from "./daily-closing";

/**
 * Express application used by Netlify Functions. The normal local server in
 * server/_core/index.ts remains unchanged for local development.
 */
export function createNetlifyApp() {
  const app = express();
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // Netlify rewrite targets can strip the /api prefix before Express sees it.
  // Normalize those paths so the original route contracts remain unchanged.
  app.use((req, _res, next) => {
    if (req.url.startsWith("/oauth/")) req.url = `/api${req.url}`;
    if (req.url.startsWith("/storage/")) req.url = `/manus-storage${req.url.slice("/storage".length)}`;
    next();
  });
  registerStorageProxy(app);
  registerOAuthRoutes(app);

  const dailyClosingHandler = async (req: express.Request, res: express.Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
      return res.json({ ok: true, result: await closeAllWorkspaces() });
    } catch (error) {
      return res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
    }
  };
  app.post("/api/scheduled/daily-closing", dailyClosingHandler);
  app.post("/scheduled/daily-closing", dailyClosingHandler);

  const trpcMiddleware = createExpressMiddleware({ router: appRouter, createContext });
  app.use("/api/trpc", trpcMiddleware);
  app.use("/trpc", trpcMiddleware);
  return app;
}
