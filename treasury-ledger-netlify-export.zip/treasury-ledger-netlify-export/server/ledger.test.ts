import { describe, expect, it } from "vitest";
import { assertBalanced, calculateBalanceCents, centsToMoney, moneyToCents } from "./ledger";

describe("ledger arithmetic", () => {
  it("converts monetary values without floating point drift", () => {
    expect(moneyToCents("5000.10")).toBe(500010);
    expect(moneyToCents("0.5")).toBe(50);
    expect(centsToMoney(500010)).toBe("5000.10");
  });

  it("derives debit-nature and credit-nature balances correctly", () => {
    expect(calculateBalanceCents("asset", "1000.00", "250.25", "10.10")).toBe(124015);
    expect(calculateBalanceCents("liability", "1000.00", "250.25", "10.10")).toBe(75985);
  });

  it("accepts balanced entries and rejects unbalanced entries", () => {
    expect(assertBalanced([
      { entryType: "debit", amount: "5000.00" },
      { entryType: "credit", amount: "5000.00" },
    ])).toEqual({ debits: 500000, credits: 500000 });
    expect(() => assertBalanced([
      { entryType: "debit", amount: "5000.00" },
      { entryType: "credit", amount: "4999.99" },
    ])).toThrow("equal positive debit and credit totals");
  });
});
