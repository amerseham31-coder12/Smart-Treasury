import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { auditLogs, clientCredentials, users, workspaceMembers } from "../drizzle/schema";
import { getSessionCookieOptions } from "./_core/cookies";
import { ENV } from "./_core/env";
import { sdk } from "./_core/sdk";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getDb, ensureWorkspaceForUser } from "./db";
import { verifyPassword, hashPassword } from "./auth/password";
import { dashboardRouter } from "./routers/dashboard";
import { transactionsRouter } from "./routers/transactions";
import { accountsRouter } from "./routers/accounts";
import { customersRouter } from "./routers/customers";
import { adminProcedure, workspaceProcedure } from "./routers/_shared";
import { financeRouter } from "./routers/finance";

const clientUsername = z.string().min(3).max(80).regex(/^[a-zA-Z0-9._-]+$/, "اسم المستخدم يجب أن يحتوي على حروف أو أرقام فقط");
const clientPassword = z.string().min(8).max(128);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) return null;
      const workspace = await ensureWorkspaceForUser(ctx.user.id);
      return { ...ctx.user, workspaceRole: workspace.role };
    }),
    login: publicProcedure
      .input(z.object({ username: clientUsername, password: clientPassword }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const username = input.username.trim().toLowerCase();
        const [record] = await db.select({ credential: clientCredentials, user: users })
          .from(clientCredentials)
          .innerJoin(users, eq(users.id, clientCredentials.userId))
          .where(and(eq(clientCredentials.username, username), eq(clientCredentials.isActive, true)))
          .limit(1);
        if (!record || !verifyPassword(input.password, record.credential.passwordSalt, record.credential.passwordHash)) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "اسم المستخدم أو كلمة المرور غير صحيحة" });
        }
        const token = await sdk.signSession({ openId: record.user.openId, appId: ENV.appId, name: record.user.name ?? username });
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
        await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, record.user.id));
        return { success: true as const };
      }),
    createClient: adminProcedure
      .input(z.object({ username: clientUsername, password: clientPassword, name: z.string().min(2).max(160) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const username = input.username.trim().toLowerCase();
        const [existing] = await db.select({ id: clientCredentials.id }).from(clientCredentials).where(eq(clientCredentials.username, username)).limit(1);
        if (existing) throw new TRPCError({ code: "CONFLICT", message: "اسم المستخدم مستخدم بالفعل" });
        const { salt, hash } = hashPassword(input.password);
        return db.transaction(async tx => {
          const [newUser] = await tx.insert(users).values({
            openId: `password:${username}`,
            name: input.name,
            loginMethod: "password",
            role: "user",
          });
          const userId = Number(newUser.insertId);
          await tx.insert(workspaceMembers).values({ workspaceId: ctx.workspace.workspaceId, userId, role: "client" });
          const [credential] = await tx.insert(clientCredentials).values({
            username,
            passwordHash: hash,
            passwordSalt: salt,
            userId,
            workspaceId: ctx.workspace.workspaceId,
          });
          await tx.insert(auditLogs).values({
            workspaceId: ctx.workspace.workspaceId,
            actorUserId: ctx.user.id,
            action: "client.created",
            entityType: "client_credential",
            entityId: String(credential.insertId),
            metadata: { username },
          });
          return { success: true as const, username };
        });
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: dashboardRouter,
  transactions: transactionsRouter,
  accounts: accountsRouter,
  customers: customersRouter,
  finance: financeRouter,
});

export type AppRouter = typeof appRouter;
