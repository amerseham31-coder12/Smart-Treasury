import { and, eq, gte, lt, sql } from "drizzle-orm";
import { commissions, customerPayables, dailyClosings, personalExpenses, transactions, workspaces } from "../drizzle/schema";
import { getDb, getDerivedAccounts } from "./db";

function cairoDate(date = new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo", year: "numeric", month: "2-digit", day: "2-digit" }).format(date);
}

function dayBounds(dateString: string) {
  const start = new Date(`${dateString}T00:00:00+03:00`);
  const end = new Date(start.getTime() + 86_400_000);
  return { start, end };
}

export async function closeWorkspaceDay(workspaceId: number, closingDate = cairoDate(new Date(Date.now() - 86_400_000))) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const { start, end } = dayBounds(closingDate);
  const [alreadyClosed] = await db.select({ id: dailyClosings.id, isReopened: dailyClosings.isReopened })
    .from(dailyClosings)
    .where(and(eq(dailyClosings.workspaceId, workspaceId), eq(dailyClosings.closingDate, new Date(`${closingDate}T00:00:00Z`))))
    .limit(1);
  if (alreadyClosed && !alreadyClosed.isReopened) return { id: alreadyClosed.id, skipped: true as const, closingDate };

  const [movement] = await db.select({
    inflows: sql<string>`COALESCE(SUM(CASE WHEN ${transactions.transactionType} IN ('deposit','customer_receipt') THEN ${transactions.amount} ELSE 0 END),0)`,
    outflows: sql<string>`COALESCE(SUM(CASE WHEN ${transactions.transactionType} IN ('withdrawal','customer_transfer','expense') THEN ${transactions.amount} ELSE 0 END),0)`,
    count: sql<number>`COUNT(*)`,
  }).from(transactions).where(and(eq(transactions.workspaceId, workspaceId), eq(transactions.status, "posted"), gte(transactions.postedAt, start), lt(transactions.postedAt, end)));
  const [fees] = await db.select({
    incoming: sql<string>`COALESCE(SUM(CASE WHEN ${commissions.commissionType} = 'incoming' THEN ${commissions.amount} ELSE 0 END),0)`,
    outgoing: sql<string>`COALESCE(SUM(CASE WHEN ${commissions.commissionType} = 'outgoing' THEN ${commissions.amount} ELSE 0 END),0)`,
  }).from(commissions).where(and(eq(commissions.workspaceId, workspaceId), gte(commissions.createdAt, start), lt(commissions.createdAt, end)));
  const [expenses] = await db.select({ total: sql<string>`COALESCE(SUM(${personalExpenses.amount}),0)` }).from(personalExpenses)
    .where(and(eq(personalExpenses.workspaceId, workspaceId), gte(personalExpenses.createdAt, start), lt(personalExpenses.createdAt, end)));
  const [payables] = await db.select({ total: sql<string>`COALESCE(SUM(${customerPayables.dueAmount} - ${customerPayables.paidAmount}),0)` })
    .from(customerPayables).where(and(eq(customerPayables.workspaceId, workspaceId), eq(customerPayables.status, "pending")));
  const accounts = await getDerivedAccounts(workspaceId);
  const openingBalance = accounts.reduce((sum, account) => sum + account.openingBalance, 0);
  const closingBalance = accounts.reduce((sum, account) => sum + account.balance, 0);
  const vodafoneMovements = accounts.filter(account => account.providerType === "vodafone_cash")
    .reduce((sum, account) => sum + account.debitTotal + account.creditTotal, 0);
  const warnings = accounts.filter(account => account.lowBalanceThreshold > 0 && account.balance < account.lowBalanceThreshold).map(account => `${account.name}: low balance`);

  const values = {
    workspaceId,
    closingDate: new Date(`${closingDate}T00:00:00Z`),
    openingBalance: openingBalance.toFixed(2),
    totalInflows: String(movement?.inflows ?? "0.00"),
    totalOutflows: String(movement?.outflows ?? "0.00"),
    incomingCommissions: String(fees?.incoming ?? "0.00"),
    outgoingCommissions: String(fees?.outgoing ?? "0.00"),
    personalExpenses: String(expenses?.total ?? "0.00"),
    vodafoneMovements: vodafoneMovements.toFixed(2),
    customerPayables: String(payables?.total ?? "0.00"),
    closingBalance: closingBalance.toFixed(2),
    transactionCount: Number(movement?.count ?? 0),
    warnings,
    isReopened: false,
  };
  if (alreadyClosed) {
    await db.update(dailyClosings).set(values).where(eq(dailyClosings.id, alreadyClosed.id));
    return { id: alreadyClosed.id, skipped: false as const, closingDate };
  }
  const [created] = await db.insert(dailyClosings).values(values);
  return { id: Number(created.insertId), skipped: false as const, closingDate };
}

export async function closeAllWorkspaces() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const rows = await db.select({ id: workspaces.id }).from(workspaces);
  const results = [];
  for (const row of rows) results.push(await closeWorkspaceDay(row.id));
  return results;
}
