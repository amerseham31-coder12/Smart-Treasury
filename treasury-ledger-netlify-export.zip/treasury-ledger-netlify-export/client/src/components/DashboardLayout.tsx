import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { startLogin } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Activity, BarChart3, Bell, ClipboardCheck, FilePlus2, FileText, KeyRound, LayoutDashboard, Landmark, Loader2, LogOut, PanelLeft, ReceiptText, Users, WalletCards, Zap } from "lucide-react";
import { CSSProperties, useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

const adminMenuItems = [
  { icon: LayoutDashboard, label: "لوحة التحكم", path: "/" },
  { icon: WalletCards, label: "الخزينة والحسابات", path: "/accounts" },
  { icon: Users, label: "العملاء", path: "/customers" },
  { icon: ReceiptText, label: "العمليات المالية", path: "/transactions" },
  { icon: BarChart3, label: "التقارير", path: "/reports" },
  { icon: ClipboardCheck, label: "التسوية اليومية", path: "/reconciliation" },
  { icon: KeyRound, label: "حسابات العملاء", path: "/client-users" },
  { icon: WalletCards, label: "Vodafone Cash Accounts", path: "/vodafone-accounts" },
  { icon: ReceiptText, label: "Commissions", path: "/commissions" },
  { icon: Landmark, label: "Customer Payables", path: "/payables" },
  { icon: ReceiptText, label: "Personal Expenses", path: "/expenses" },
  { icon: FileText, label: "Master Report", path: "/master-report" },
  { icon: ClipboardCheck, label: "Daily Closing", path: "/daily-closing" },
];

const clientMenuItems = [
  { icon: Landmark, label: "رأس مالي", path: "/capital" },
  { icon: WalletCards, label: "Vodafone Cash", path: "/vodafone" },
  { icon: Zap, label: "InstaPay", path: "/instapay" },
  { icon: FileText, label: "تقرير العمليات", path: "/operations-report" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;
const MIN_WIDTH = 220;
const MAX_WIDTH = 420;

function ClientLoginCard() {
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({ username: "", password: "" });
  const login = trpc.auth.login.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      setLocation("/capital");
      toast.success("تم تسجيل الدخول بنجاح");
    },
    onError: error => toast.error(error.message),
  });
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    login.mutate(form);
  };
  return <div className="flex min-h-screen items-center justify-center bg-[#f7f8f7] p-6"><div className="w-full max-w-md rounded-3xl border border-slate-100 bg-white p-8 shadow-[0_20px_60px_rgba(21,37,59,0.09)]"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#15253b] text-white"><WalletCards className="h-7 w-7" /></div><div className="mt-6 text-center"><h1 className="text-2xl font-bold text-[#15253b]">بوابة العميل</h1><p className="mt-3 text-sm leading-6 text-slate-500">ادخل باسم المستخدم وكلمة المرور لمتابعة رأس مالك والحسابات والتقارير.</p></div><form className="mt-7 space-y-4" onSubmit={submit}><div><label className="text-sm font-medium text-slate-700">اسم المستخدم</label><Input className="mt-1.5 h-11" dir="ltr" placeholder="client_name" value={form.username} onChange={event => setForm({ ...form, username: event.target.value })} required /></div><div><label className="text-sm font-medium text-slate-700">كلمة المرور</label><Input className="mt-1.5 h-11" dir="ltr" type="password" placeholder="••••••••" value={form.password} onChange={event => setForm({ ...form, password: event.target.value })} required /></div><Button type="submit" disabled={login.isPending} className="h-11 w-full gap-2 bg-[#d07b42] text-white hover:bg-[#bb6934]">{login.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />} دخول العميل</Button></form><div className="my-6 flex items-center gap-3"><div className="h-px flex-1 bg-slate-100" /><span className="text-xs text-slate-400">أو</span><div className="h-px flex-1 bg-slate-100" /></div><Button type="button" variant="outline" onClick={() => startLogin()} className="h-11 w-full border-slate-200 text-slate-600">دخول الإدارة</Button></div></div>;
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  useEffect(() => { localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString()); }, [sidebarWidth]);

  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) return <ClientLoginCard />;

  return <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}><DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent></SidebarProvider>;
}

type DashboardLayoutContentProps = { children: React.ReactNode; setSidebarWidth: (width: number) => void };

function DashboardLayoutContent({ children, setSidebarWidth }: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const menuItems = useMemo(() => user?.workspaceRole === "client" ? clientMenuItems : adminMenuItems, [user?.workspaceRole]);
  const activeMenuItem = menuItems.find(item => item.path === location);

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      if (!isResizing) return;
      const sidebarRight = sidebarRef.current?.getBoundingClientRect().right ?? window.innerWidth;
      const newWidth = sidebarRight - event.clientX;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) setSidebarWidth(newWidth);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return <><div className="relative" ref={sidebarRef}><Sidebar side="right" collapsible="icon" className="border-l-0" disableTransition={isResizing}><SidebarHeader className="h-[88px] justify-center border-b border-white/10 bg-[#15253b] text-white"><div className="flex w-full items-center gap-3 px-2"><button onClick={toggleSidebar} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white/60 transition hover:bg-white/10 hover:text-white" aria-label="طي القائمة"><PanelLeft className="h-4 w-4" /></button>{!isCollapsed ? <div className="flex min-w-0 items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#d07b42] shadow-lg shadow-[#d07b42]/20"><WalletCards className="h-5 w-5 text-white" /></span><div className="min-w-0"><p className="truncate text-sm font-bold">خزينة</p><p className="truncate text-[11px] text-white/50">{user?.workspaceRole === "client" ? "Client Portal" : "Treasury Ledger"}</p></div></div> : null}</div></SidebarHeader><SidebarContent className="gap-0 bg-[#15253b] px-3 py-5"><p className={`mb-3 px-3 text-[10px] font-semibold tracking-[0.18em] text-white/35 ${isCollapsed ? "hidden" : "block"}`}>{user?.workspaceRole === "client" ? "حسابي المالي" : "الإدارة المالية"}</p><SidebarMenu>{menuItems.map(item => { const isActive = location === item.path; return <SidebarMenuItem key={item.path}><SidebarMenuButton isActive={isActive} onClick={() => setLocation(item.path)} tooltip={item.label} className={`mb-1 h-11 rounded-xl font-normal transition ${isActive ? "bg-white/12 text-white shadow-sm hover:bg-white/15 hover:text-white" : "text-white/55 hover:bg-white/8 hover:text-white"}`}><item.icon className={`h-[18px] w-[18px] ${isActive ? "text-[#f1b17f]" : ""}`} /><span>{item.label}</span></SidebarMenuButton></SidebarMenuItem>; })}</SidebarMenu><div className={`mt-7 rounded-2xl border border-white/10 bg-white/5 p-3 ${isCollapsed ? "hidden" : "block"}`}><div className="flex items-center gap-2 text-[#7dd3c7]"><Activity className="h-4 w-4" /><span className="text-xs font-semibold">{user?.workspaceRole === "client" ? "بيانات لحظية" : "حالة النظام"}</span></div><p className="mt-2 text-[11px] leading-5 text-white/45">{user?.workspaceRole === "client" ? "الأرقام مرتبطة مباشرة بالحركات المسجلة." : "كل الأرصدة مشتقة من سجل الحركات المركزي."}</p></div></SidebarContent><SidebarFooter className="bg-[#15253b] p-3"><DropdownMenu><DropdownMenuTrigger asChild><button className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-right transition hover:bg-white/8"><Avatar className="h-9 w-9 shrink-0 border border-white/15"><AvatarFallback className="bg-[#d07b42] text-xs font-semibold text-white">{user?.name?.charAt(0).toUpperCase() || "م"}</AvatarFallback></Avatar>{!isCollapsed && <div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold text-white">{user?.name || "المستخدم"}</p><p className="mt-1 truncate text-[10px] text-white/45">{user?.email || (user?.workspaceRole === "client" ? "بوابة العميل" : "حساب مصادق")}</p></div>}</button></DropdownMenuTrigger><DropdownMenuContent align="start" className="w-52"><DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive"><LogOut className="ml-2 h-4 w-4" /><span>تسجيل الخروج</span></DropdownMenuItem></DropdownMenuContent></DropdownMenu></SidebarFooter></Sidebar><div className={`absolute left-0 top-0 h-full w-1 cursor-col-resize transition-colors hover:bg-[#d07b42]/30 ${isCollapsed ? "hidden" : "block"}`} onMouseDown={() => setIsResizing(true)} style={{ zIndex: 50 }} /></div><SidebarInset className="bg-[#f7f8f7]">{isMobile && <div className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-slate-100 bg-white/90 px-3 backdrop-blur"><div className="flex items-center gap-3"><SidebarTrigger className="h-9 w-9 rounded-lg" /><span className="text-sm font-semibold text-[#15253b]">{activeMenuItem?.label ?? "القائمة"}</span></div><Bell className="h-4 w-4 text-slate-400" /></div>}<main className="flex-1 p-4 sm:p-6 lg:p-8">{children}</main></SidebarInset></>;
}
