export type QueuedTransaction = {
  clientMutationId: string;
  transactionType: "deposit" | "withdrawal" | "customer_transfer" | "customer_receipt" | "internal_transfer" | "expense" | "adjustment";
  sourceAccountId?: number;
  destinationAccountId?: number;
  customerId?: number;
  amount: string;
  feeAmount: string;
  commissionType?: "incoming" | "outgoing";
  expenseType?: string;
  expenseDescription?: string;
  externalReference?: string;
  notes?: string;
};

const STORAGE_KEY = "treasury-ledger-offline-transactions";

export function readQueuedTransactions(): QueuedTransaction[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as QueuedTransaction[];
  } catch {
    return [];
  }
}

export function queueTransaction(transaction: Omit<QueuedTransaction, "clientMutationId">) {
  const queued = [...readQueuedTransactions(), { ...transaction, clientMutationId: crypto.randomUUID() }];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(queued));
  window.dispatchEvent(new Event("offline-queue-changed"));
  return queued.at(-1)!;
}

export function removeQueuedTransaction(clientMutationId: string) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(readQueuedTransactions().filter(item => item.clientMutationId !== clientMutationId)));
  window.dispatchEvent(new Event("offline-queue-changed"));
}
