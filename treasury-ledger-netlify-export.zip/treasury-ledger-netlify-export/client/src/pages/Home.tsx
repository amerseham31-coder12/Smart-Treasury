import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import {
  ArrowDownLeft,
  ArrowUpLeft,
  Banknote,
  Bell,
  CircleAlert,
  CreditCard,
  FileText,
  Landmark,
  Plus,
  RefreshCw,
  ShieldCheck,
  Users,
  WalletCards,
  Zap,
} from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

const money = new Intl.NumberFormat("ar-EG", {
  style: "currency",
  currency: "EGP",
  maximumFractionDigits: 2,
});

const number = new Intl.NumberFormat("ar-EG");

function formatMoney(value: number | string | null | undefined) {
  return money.format(Number(value ?? 0));
}

function transactionLabel(type: string) {
  const labels: Record<string, string> = {
    deposit: "إيداع",
    withdrawal: "سحب",
    customer_transfer: "تحويل إلى عميل",
    customer_receipt: "استلام من عميل",
    internal_transfer: "تحويل داخلي",
    expense: "مصروف",
    adjustment: "تسوية",
    reversal: "عكس عملية",
  };
  return labels[type] ?? type;
}

function statusLabel(status: string) {
  if (status === "posted") return "منشورة";
  if (status === "reversed") return "معكوسة";
  return "معلقة";
}

function StatCard({ title, value, caption, icon: Icon, tone = "navy" }: { title: string; value: string; caption: string; icon: typeof WalletCards; tone?: "navy" | "teal" | "amber" | "violet" }) {
  const tones = {
    navy: "bg-[#15253b] text-white",
    teal: "bg-[#0f766e] text-white",
    amber: "bg-[#f6f0df] text-[#684d16]",
    violet: "bg-[#ebe7f7] text-[#51427d]",
  };
  return (
    <Card className="border-0 shadow-[0_16px_40px_rgba(21,37,59,0.07)] overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className={`text-sm font-medium ${tone === "navy" || tone === "teal" ? "text-white/70" : "text-slate-500"}`}>{title}</p>
            <p className={`mt-3 text-2xl font-bold tracking-tight ${tone === "navy" || tone === "teal" ? "text-white" : "text-[#15253b]"}`}>{value}</p>
            <p className={`mt-2 text-xs ${tone === "navy" || tone === "teal" ? "text-white/60" : "text-slate-500"}`}>{caption}</p>
          </div>
          <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${tones[tone]}`}>
            <Icon className="h-5 w-5" />
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4"><div><Skeleton className="h-4 w-28" /><Skeleton className="mt-3 h-9 w-64" /></div><Skeleton className="h-10 w-36" /></div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-36 rounded-2xl" />)}</div>
      <div className="grid gap-5 xl:grid-cols-[1.4fr_0.6fr]"><Skeleton className="h-96 rounded-2xl" /><Skeleton className="h-96 rounded-2xl" /></div>
    </div>
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  useEffect(() => {
    if (user?.workspaceRole === "client") setLocation("/capital");
  }, [setLocation, user?.workspaceRole]);
  const { data, isLoading, isError, refetch, isFetching } = trpc.dashboard.overview.useQuery(undefined, {
    refetchInterval: 30_000,
    retry: false,
    enabled: user?.workspaceRole !== "client",
  });

  if (isLoading) return <DashboardSkeleton />;

  const balances = data?.balances;
  const accounts = data?.accounts ?? [];
  const recent = data?.recent ?? [];
  const alerts = data?.alerts ?? [];
  const hasAccounts = accounts.length > 0;

  return (
    <div className="space-y-7 pb-10">
      <section className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
        <div>
          <div className="flex items-center gap-2 text-sm text-[#0f766e]"><span className="h-2 w-2 rounded-full bg-[#0f766e]" /> النظام متصل · آخر تحديث تلقائي</div>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-[#15253b]">لوحة التحكم المالية</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">نظرة موحدة على الخزينة، الحسابات، والعملاء مع أرصدة محسوبة مباشرة من سجل الحركات.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="h-10 gap-2 border-slate-200 bg-white text-slate-600" onClick={() => refetch()} disabled={isFetching}><RefreshCw className={`h-4 w-4 ${isFetching ? "animate-spin" : ""}`} /> تحديث</Button>
          <Button className="h-10 gap-2 bg-[#d07b42] px-4 text-white shadow-lg shadow-[#d07b42]/20 hover:bg-[#bb6934]" onClick={() => setLocation("/transactions/new")}><Plus className="h-4 w-4" /> عملية جديدة</Button>
        </div>
      </section>

      {isError && <Card className="border-amber-200 bg-amber-50/70"><CardContent className="flex items-center gap-3 p-4 text-sm text-amber-900"><CircleAlert className="h-5 w-5 shrink-0" /><div><p className="font-semibold">تعذر تحميل بيانات اللوحة</p><p className="mt-1 text-amber-800/80">تحقق من جلسة الدخول أو اتصال قاعدة البيانات ثم أعد المحاولة.</p></div></CardContent></Card>}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="إجمالي رصيد الخزينة" value={formatMoney(balances?.treasury)} caption="الرصيد المشتق من الـLedger" icon={Landmark} tone="navy" />
        <StatCard title="Vodafone Cash" value={formatMoney(balances?.vodafoneCash)} caption="جميع الحسابات النشطة" icon={WalletCards} tone="teal" />
        <StatCard title="InstaPay" value={formatMoney(balances?.instapay)} caption="جميع الحسابات النشطة" icon={Zap} tone="violet" />
        <StatCard title="صافي الرصيد المتاح" value={formatMoney(balances?.netAvailable)} caption={`${number.format(data?.today.transactionCount ?? 0)} عملية اليوم`} icon={Banknote} tone="amber" />
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.45fr_0.55fr]">
        <Card className="border-0 shadow-[0_16px_40px_rgba(21,37,59,0.07)]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 border-b border-slate-100 px-6 py-5">
            <div><CardTitle className="text-base text-[#15253b]">ملخص حركة اليوم</CardTitle><p className="mt-1 text-xs text-slate-500">الأرقام من العمليات المنشورة فقط</p></div>
            <div className="rounded-xl bg-[#f5f7f8] p-2 text-[#0f766e]"><FileText className="h-5 w-5" /></div>
          </CardHeader>
          <CardContent className="grid gap-6 p-6 sm:grid-cols-3">
            <div><p className="text-xs text-slate-500">إجمالي الداخل</p><p className="mt-2 text-xl font-bold text-[#0f766e]">{formatMoney(data?.today.incoming)}</p><div className="mt-4 h-2 rounded-full bg-slate-100"><div className="h-2 w-[68%] rounded-full bg-[#0f766e]" /></div></div>
            <div><p className="text-xs text-slate-500">إجمالي الخارج</p><p className="mt-2 text-xl font-bold text-[#d07b42]">{formatMoney(data?.today.outgoing)}</p><div className="mt-4 h-2 rounded-full bg-slate-100"><div className="h-2 w-[42%] rounded-full bg-[#d07b42]" /></div></div>
            <div><p className="text-xs text-slate-500">عدد العمليات</p><p className="mt-2 text-xl font-bold text-[#15253b]">{number.format(data?.today.transactionCount ?? 0)}</p><p className="mt-4 text-xs text-slate-500">تحديث مباشر عند نشر أي حركة</p></div>
          </CardContent>
        </Card>
        <Card className="border-0 bg-[#15253b] text-white shadow-[0_16px_40px_rgba(21,37,59,0.15)]">
          <CardContent className="flex h-full flex-col justify-between p-6">
            <div><div className="flex items-center justify-between"><span className="rounded-full bg-white/10 px-3 py-1 text-xs text-white/70">صحة النظام</span><ShieldCheck className="h-5 w-5 text-[#7dd3c7]" /></div><h2 className="mt-8 text-xl font-semibold">سجل مالي قابل للمراجعة</h2><p className="mt-2 text-sm leading-6 text-white/60">لا حذف للعمليات. كل تصحيح يتم عبر حركة عكسية مرتبطة بالأصل.</p></div>
            <div className="mt-8 border-t border-white/10 pt-4 text-xs text-white/50">العملة الأساسية · EGP</div>
          </CardContent>
        </Card>
      </section>

      {!hasAccounts && <Card className="border-[#cde8e5] bg-[#f0fbfa] shadow-none"><CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between"><div className="flex gap-3"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white text-[#0f766e] shadow-sm"><Plus className="h-5 w-5" /></span><div><p className="font-semibold text-[#15253b]">ابدأ بتعريف أول حساب مالي</p><p className="mt-1 text-sm text-slate-500">أضف الخزينة أو Vodafone Cash أو InstaPay حتى تبدأ الأرصدة في الظهور من الـLedger.</p></div></div><Button variant="outline" className="border-[#a9d9d4] bg-white text-[#0f766e]" onClick={() => setLocation("/accounts")}>إدارة الحسابات</Button></CardContent></Card>}

      <section className="grid gap-5 xl:grid-cols-[1.45fr_0.55fr]">
        <Card className="border-0 shadow-[0_16px_40px_rgba(21,37,59,0.07)]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 px-6 py-5"><div><CardTitle className="text-base text-[#15253b]">آخر العمليات</CardTitle><p className="mt-1 text-xs text-slate-500">آخر 8 حركات مالية منشورة</p></div><Button variant="ghost" className="text-xs text-[#0f766e]" onClick={() => setLocation("/transactions")}>عرض الكل</Button></CardHeader>
          <CardContent className="p-0">
            {recent.length === 0 ? <div className="flex flex-col items-center justify-center px-6 py-14 text-center"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400"><CreditCard className="h-6 w-6" /></div><p className="mt-4 font-semibold text-[#15253b]">لا توجد عمليات بعد</p><p className="mt-1 max-w-sm text-sm text-slate-500">ستظهر هنا العمليات بعد تسجيلها واعتمادها، مع رقم مرجعي يمكن تتبعه.</p></div> : <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-right text-sm"><thead className="border-y border-slate-100 bg-slate-50/70 text-xs text-slate-500"><tr><th className="px-6 py-3 font-medium">رقم العملية</th><th className="px-4 py-3 font-medium">النوع</th><th className="px-4 py-3 font-medium">المسار</th><th className="px-4 py-3 font-medium">المبلغ</th><th className="px-6 py-3 font-medium">الحالة</th></tr></thead><tbody>{recent.map(item => <tr key={item.id} className="border-b border-slate-100 last:border-0"><td className="px-6 py-4 font-mono text-xs text-[#15253b]">{item.transactionId}</td><td className="px-4 py-4 text-slate-600">{transactionLabel(item.transactionType)}</td><td className="px-4 py-4 text-xs text-slate-500">{item.sourceName ?? "—"} <span className="px-1 text-slate-300">←</span> {item.destinationName ?? "—"}</td><td className="px-4 py-4 font-semibold text-[#15253b]">{formatMoney(item.amount)}</td><td className="px-6 py-4"><Badge className={item.status === "posted" ? "bg-[#e6f5f2] text-[#0f766e] hover:bg-[#e6f5f2]" : "bg-slate-100 text-slate-600 hover:bg-slate-100"}>{statusLabel(item.status)}</Badge></td></tr>)}</tbody></table></div>}
          </CardContent>
        </Card>

        <Card className="border-0 shadow-[0_16px_40px_rgba(21,37,59,0.07)]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 px-6 py-5"><div><CardTitle className="text-base text-[#15253b]">التنبيهات</CardTitle><p className="mt-1 text-xs text-slate-500">تحتاج إلى مراجعة</p></div><div className="rounded-xl bg-[#fff3e8] p-2 text-[#d07b42]"><Bell className="h-5 w-5" /></div></CardHeader>
          <CardContent className="space-y-3 px-6 pb-6">
            {alerts.length === 0 ? <div className="py-8 text-center"><div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full bg-[#e6f5f2] text-[#0f766e]"><ShieldCheck className="h-5 w-5" /></div><p className="mt-3 text-sm font-semibold text-[#15253b]">لا توجد تنبيهات مفتوحة</p><p className="mt-1 text-xs text-slate-500">كل المؤشرات ضمن الحدود المعرفة حاليًا.</p></div> : alerts.map(alert => <div key={alert.id} className="flex gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-3"><span className={`mt-0.5 h-2.5 w-2.5 shrink-0 rounded-full ${alert.severity === "critical" ? "bg-red-500" : "bg-amber-400"}`} /><div><p className="text-sm font-semibold text-[#15253b]">{alert.title}</p><p className="mt-1 text-xs leading-5 text-slate-500">{alert.message}</p></div></div>)}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        <button className="group rounded-2xl border border-slate-100 bg-white p-5 text-right shadow-[0_10px_30px_rgba(21,37,59,0.04)] transition hover:-translate-y-0.5 hover:shadow-lg" onClick={() => setLocation("/accounts")}><div className="flex items-center justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e6f5f2] text-[#0f766e]"><WalletCards className="h-5 w-5" /></span><ArrowUpLeft className="h-4 w-4 text-slate-300 transition group-hover:-translate-y-0.5 group-hover:text-[#0f766e]" /></div><p className="mt-4 font-semibold text-[#15253b]">الحسابات والتحويلات</p><p className="mt-1 text-xs text-slate-500">إدارة Vodafone Cash وInstaPay والخزينة</p></button>
        <button className="group rounded-2xl border border-slate-100 bg-white p-5 text-right shadow-[0_10px_30px_rgba(21,37,59,0.04)] transition hover:-translate-y-0.5 hover:shadow-lg" onClick={() => setLocation("/customers")}><div className="flex items-center justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#ebe7f7] text-[#51427d]"><Users className="h-5 w-5" /></span><ArrowUpLeft className="h-4 w-4 text-slate-300 transition group-hover:-translate-y-0.5 group-hover:text-[#51427d]" /></div><p className="mt-4 font-semibold text-[#15253b]">حسابات العملاء</p><p className="mt-1 text-xs text-slate-500">الأرصدة والحدود الائتمانية وكشوف الحساب</p></button>
        <button className="group rounded-2xl border border-slate-100 bg-white p-5 text-right shadow-[0_10px_30px_rgba(21,37,59,0.04)] transition hover:-translate-y-0.5 hover:shadow-lg" onClick={() => setLocation("/reports")}><div className="flex items-center justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#fff3e8] text-[#d07b42]"><ArrowDownLeft className="h-5 w-5" /></span><ArrowUpLeft className="h-4 w-4 text-slate-300 transition group-hover:-translate-y-0.5 group-hover:text-[#d07b42]" /></div><p className="mt-4 font-semibold text-[#15253b]">التقارير والتسويات</p><p className="mt-1 text-xs text-slate-500">تقرير يومي وحركة العمليات والتسوية</p></button>
      </section>
    </div>
  );
}
