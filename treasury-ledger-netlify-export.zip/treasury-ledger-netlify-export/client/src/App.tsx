import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import DashboardLayout from "@/components/DashboardLayout";
import ErrorBoundary from "@/components/ErrorBoundary";
import FeaturePage from "@/pages/FeaturePage";
import AdvancedFinancePage from "@/pages/AdvancedFinancePage";
import Home from "@/pages/Home";
import NotFound from "@/pages/NotFound";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { Route, Switch } from "wouter";

function Shell({ children }: { children: React.ReactNode }) {
  return <DashboardLayout>{children}</DashboardLayout>;
}

function FeatureRoute({ kind }: { kind: "accounts" | "customers" | "transactions" | "new-transaction" | "reports" | "reconciliation" | "users" | "capital" | "vodafone" | "instapay" | "operations-report" | "client-users" }) {
  return <Shell><FeaturePage kind={kind} /></Shell>;
}

function Router() {
  return (
    <Switch>
      <Route path="/"><Shell><Home /></Shell></Route>
      <Route path="/accounts"><FeatureRoute kind="accounts" /></Route>
      <Route path="/customers"><FeatureRoute kind="customers" /></Route>
      <Route path="/transactions"><FeatureRoute kind="transactions" /></Route>
      <Route path="/transactions/new"><FeatureRoute kind="new-transaction" /></Route>
      <Route path="/reports"><FeatureRoute kind="reports" /></Route>
      <Route path="/reconciliation"><FeatureRoute kind="reconciliation" /></Route>
      <Route path="/users"><FeatureRoute kind="users" /></Route>
      <Route path="/capital"><FeatureRoute kind="capital" /></Route>
      <Route path="/vodafone"><FeatureRoute kind="vodafone" /></Route>
      <Route path="/instapay"><FeatureRoute kind="instapay" /></Route>
      <Route path="/operations-report"><FeatureRoute kind="operations-report" /></Route>
      <Route path="/client-users"><FeatureRoute kind="client-users" /></Route>
      <Route path="/vodafone-accounts"><Shell><AdvancedFinancePage kind="vodafone-accounts" /></Shell></Route>
      <Route path="/commissions"><Shell><AdvancedFinancePage kind="commissions" /></Shell></Route>
      <Route path="/payables"><Shell><AdvancedFinancePage kind="payables" /></Shell></Route>
      <Route path="/expenses"><Shell><AdvancedFinancePage kind="expenses" /></Shell></Route>
      <Route path="/master-report"><Shell><AdvancedFinancePage kind="master-report" /></Shell></Route>
      <Route path="/daily-closing"><Shell><AdvancedFinancePage kind="daily-closing" /></Shell></Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <div dir="rtl" className="min-h-screen bg-[#f7f8f7]">
            <Toaster />
            <Router />
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
