# Treasury Ledger — Complete Netlify Export

This is the complete source export of the Treasury Ledger application at the requested checkpoint. It includes the React frontend, Express/tRPC backend, Drizzle schema and migrations, authentication flow, ledger/accounting logic, finance modules, tests, styles, icons, configuration, and Netlify Functions adapter.

Start with [`NETLIFY_DEPLOYMENT.md`](./NETLIFY_DEPLOYMENT.md). It lists the build command, publish directory, required environment variables, external services, database migration requirements, and scheduler requirements.

## Quick start

```bash
pnpm install
cp .env.example .env
pnpm check
pnpm test
pnpm build:netlify
```

For a real production deployment, configure the Netlify environment variables and an external MySQL/TiDB database. The existing Manus OAuth and Forge storage integrations are retained where the current application depends on them; the deployment guide identifies each dependency.
