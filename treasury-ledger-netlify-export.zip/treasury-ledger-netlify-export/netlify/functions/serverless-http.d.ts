declare module "serverless-http" {
  import type { RequestHandler } from "express";
  type ServerlessHandler = (event: unknown, context: unknown, callback?: (error?: unknown, response?: unknown) => void) => unknown;
  export default function serverless(app: RequestHandler): ServerlessHandler;
}
